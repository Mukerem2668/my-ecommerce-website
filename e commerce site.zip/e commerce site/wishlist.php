<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'includes/header.php';
$user_id = $_SESSION['user_id'];
?>

<div class="container my-5">
    <h3 class="fw-bold mb-4"><i class="fa-solid fa-heart text-danger me-2"></i>የእኔ Wishlist</h3>

    <div class="row g-4">
        <?php
        $sql = "SELECT w.id as wishlist_id, p.* FROM wishlist w 
                JOIN products p ON w.product_id = p.id 
                WHERE w.user_id = $user_id ORDER BY w.id DESC";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
        ?>
            <div class="col-md-3">
                <div class="card h-100 shadow-sm border-0 position-relative">
                    <!-- ከ Wishlist ማጥፊያ Button -->
                    <a href="wishlist-action.php?action=remove&product_id=<?php echo $row['id']; ?>" 
                       class="btn btn-sm btn-light position-absolute top-0 end-0 m-2 rounded-circle text-danger shadow-sm"
                       title="ከ Wishlist አስወግድ">
                        <i class="fa-solid fa-xmark"></i>
                    </a>

                    <img src="<?php echo $row['image']; ?>" class="card-img-top p-3" style="height: 180px; object-fit: contain;">
                    
                    <div class="card-body d-flex flex-column">
                        <h6 class="card-title fw-bold"><?php echo htmlspecialchars($row['name']); ?></h6>
                        <p class="text-primary fw-bold mb-3">$<?php echo number_format($row['price'], 2); ?></p>
                        
                        <!-- ወደ Cart ማስተላለፊያ Form -->
                        <form action="cart.php" method="POST" class="mt-auto">
                            <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="quantity" value="1">
                            <button type="submit" name="add_to_cart" class="btn btn-primary btn-sm w-100">
                                <i class="fa-solid fa-cart-plus me-1"></i> ወደ ቅርጫት አዛውር
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php 
            endwhile;
        else:
        ?>
            <div class="col-12 text-center py-5">
                <i class="fa-regular fa-heart fs-1 text-muted mb-3 d-block"></i>
                <h5 class="text-muted">ምንም በ Wishlist ያስቀመጡት እቃ የለም።</h5>
                <a href="product.php" class="btn btn-outline-primary mt-2">እቃዎችን ይመልከቱ</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>