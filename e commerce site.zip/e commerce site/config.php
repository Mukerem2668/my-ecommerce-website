<?php
// config.php

$db_host = "localhost:3307";
$db_user = "root";
$db_pass = "";
$db_name = "e-commerce";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

define('CHAPA_SECRET_KEY', 'CHASECK_TEST-EvAZPQ3xqPKjr6Hfupl7PRfDrvYSUqW8');
// የመጨረሻውን '/transaction' አስወግደው
define('CHAPA_BASE_URL', 'https://api.chapa.co/v1'); 
define('SITE_URL', 'http://localhost/e commerce site');
// // 💵 የዶላር ወደ ብር ምንዛሬ ተመን (1 USD = 125 ETB)
define('USD_TO_ETB_RATE', 154.00); 
?>