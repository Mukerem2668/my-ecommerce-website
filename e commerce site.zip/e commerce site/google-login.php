<?php
session_start();
include 'config/db.php';

header('Content-Type: application/json');

if (isset($_POST['credential'])) {
    $jwt = $_POST['credential'];
    
    // ከ Google የመጣውን Token መፍታት
    $tokenParts = explode(".", $jwt);
    if (isset($tokenParts[1])) {
        $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $tokenParts[1])), true);
        
        if ($payload && isset($payload['email'])) {
            $email = $conn->real_escape_string($payload['email']);
            $name = $conn->real_escape_string($payload['name']);
            
            // ተጠቃሚው በ Database መኖሩን ቼክ ማድረግ
            $result = $conn->query("SELECT * FROM users WHERE email='$email'");
            
            if ($result && $result->num_rows > 0) {
                // አካውንቱ ካለ Login ማድረግ
                $user = $result->fetch_assoc();
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_role'] = $user['role'];
            } else {
                // ካሌለ አዲስ Customer አድርጎ መመዝገብ
                $random_password = password_hash(bin2hex(random_bytes(8)), PASSWORD_BCRYPT);
                $sql = "INSERT INTO users (name, email, password, role, is_verified) 
                        VALUES ('$name', '$email', '$random_password', 'customer', 1)";
                
                if ($conn->query($sql)) {
                    $_SESSION['user_id'] = $conn->insert_id;
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_role'] = 'customer';
                }
            }
            
            echo json_encode(['status' => 'success']);
            exit;
        }
    }
}

echo json_encode(['status' => 'error', 'message' => 'የ Google መረጃ መረጋገጥ አልቻለም!']);
exit;
?>