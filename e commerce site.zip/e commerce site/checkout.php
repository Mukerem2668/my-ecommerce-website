<?php
session_start();
require_once 'config.php';

// Cart ባዶ ከሆነ ወደ Cart ገፅ ይመልስ
if (empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit;
}

// 1. በ Cart ውስጥ ያሉትን ምርቶች ስም፣ የዶላር እና የብር መጠን ማስላት
$total_usd = 0;
$product_names_arr = [];

foreach ($_SESSION['cart'] as $p_id => $qty) {
    $stmt_p = $conn->prepare("SELECT name, price, stock FROM products WHERE id = ?");
    $p_id_int = intval($p_id);
    $stmt_p->bind_param("i", $p_id_int);
    $stmt_p->execute();
    $res = $stmt_p->get_result();

    if ($res && $res->num_rows > 0) {
        $prod = $res->fetch_assoc();
        $total_usd += floatval($prod['price']) * intval($qty);

        $p_name = !empty($prod['name']) ? $prod['name'] : "እቃ";
        $product_names_arr[] = $p_name . " (x" . $qty . ")";
    }
    $stmt_p->close();
}

$all_product_names = implode(", ", $product_names_arr);
$total_etb = $total_usd * (defined('USD_TO_ETB_RATE') ? USD_TO_ETB_RATE : 1);
$error_display = "";

// 2. ተጠቃሚው ትዕዛዙን ሲልክ (Manual Transfer / Transaction ID & Receipt Upload)
if (isset($_POST['submit_order'])) {
    $first_name     = trim($_POST['first_name']);
    $last_name      = trim($_POST['last_name']);
    $email          = trim($_POST['email']);
    $phone          = trim($_POST['phone']);
    $selected_city  = trim($_POST['city']);
    $selected_area  = trim($_POST['area']);
    $transaction_id = trim($_POST['transaction_id']);
    $user_id        = $_SESSION['user_id'] ?? 0;

    $amount_in_etb  = round($total_etb, 2); 
    $pickup_code    = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

    // ------------------- Receipt Upload Processing -------------------
    $receipt_path = "";
    if (isset($_FILES['receipt_image']) && $_FILES['receipt_image']['error'] == 0) {
        $allowed_ext = array('jpg', 'jpeg', 'png', 'pdf', 'webp');
        $file_name   = $_FILES['receipt_image']['name'];
        $file_tmp    = $_FILES['receipt_image']['tmp_name'];
        $file_size   = $_FILES['receipt_image']['size'];
        $file_ext    = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // Max File Size: 5MB Check
        if ($file_size > 5 * 1024 * 1024) {
            $error_display = "የደረሰኝ ፋይል መጠን ከ 5MB መብለጥ የለበትም!";
        } elseif (in_array($file_ext, $allowed_ext)) {
            $new_file_name = time() . '_' . uniqid() . '.' . $file_ext;
            $upload_dir    = "uploads/receipts/";

            // ፎልደሩ ከሌለ መፍጠር
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            if (move_uploaded_file($file_tmp, $upload_dir . $new_file_name)) {
                $receipt_path = $upload_dir . $new_file_name;
            } else {
                $error_display = "የክፍያ ደረሰኙን መጫን አልተቻለም! እባክዎን ደግመው ይሞክሩ።";
            }
        } else {
            $error_display = "እባክዎን ትክክለኛ የፎቶ ወይም PDF ፋይል (JPG, PNG, WEBP, PDF) ይምረጡ!";
        }
    }
    // -----------------------------------------------------------------

    if (empty($transaction_id)) {
        $error_display = "እባክዎን ከክፍያ በኋላ የደረሰዎትን Transaction ID ያስገቡ!";
    } elseif (empty($selected_city) || empty($selected_area)) {
        $error_display = "እባክዎን ከተማ እና ሰፈር ይምረጡ!";
    } elseif (empty($error_display)) {

        // Stock Check - በቂ ስቶክ መኖሩን ማረጋገጥ
        $has_enough_stock = true;
        foreach ($_SESSION['cart'] as $p_id => $qty) {
            $p_id_int = intval($p_id);
            $stock_stmt = $conn->prepare("SELECT name, stock FROM products WHERE id = ?");
            $stock_stmt->bind_param("i", $p_id_int);
            $stock_stmt->execute();
            $p_data = $stock_stmt->get_result()->fetch_assoc();
            $stock_stmt->close();

            if (!$p_data || $p_data['stock'] < $qty) {
                $has_enough_stock = false;
                $error_display = "ይቅርታ! '" . ($p_data['name'] ?? 'እቃ') . "' በበቂ ሁኔታ በStock የለም። የቀረው ብዛት፦ " . ($p_data['stock'] ?? 0);
                break;
            }
        }

        // Save Order & Update Stock With Database Transaction
        if ($has_enough_stock) {
            $conn->begin_transaction();

            try {
                // INSERT Query - receipt_image ተጨምሯል
                $stmt = $conn->prepare("INSERT INTO orders (user_id, first_name, last_name, email, phone, city, area, product_name, amount, tx_ref, receipt_image, status, pickup_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)");
                $stmt->bind_param("isssssssdsss", $user_id, $first_name, $last_name, $email, $phone, $selected_city, $selected_area, $all_product_names, $amount_in_etb, $transaction_id, $receipt_path, $pickup_code);            
                $stmt->execute();
                $order_id = $stmt->insert_id;
                $stmt->close();

                // Deduct Stock
                $update_stock = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");
                foreach ($_SESSION['cart'] as $p_id => $qty) {
                    $p_id_int = intval($p_id);
                    $qty_int = intval($qty);
                    $update_stock->bind_param("iii", $qty_int, $p_id_int, $qty_int);
                    $update_stock->execute();
                }
                $update_stock->close();

                $conn->commit();

                unset($_SESSION['cart']);
                header("Location: success.php?order_id=" . $order_id);
                exit();

            } catch (Exception $e) {
                $conn->rollback();
                $error_display = "ትዕዛዙን በማስመዝገብ ላይ ስህተት ተፈጥሯል፦ " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>የትዕዛዝ ማጠናቀቂያ (Checkout)</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card shadow border-0 p-4">
                <h4 class="fw-bold mb-3 text-center text-primary"><i class="fa-solid fa-cart-check me-2"></i>የትዕዛዝ ማጠናቀቂያ (Checkout)</h4>

                <?php if (!empty($error_display)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fa-solid fa-circle-exclamation me-2"></i><?php echo htmlspecialchars($error_display); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- የተመረጡ እቃዎች ዝርዝር ማሳያ -->
                <div class="card bg-light border-0 p-3 mb-3 shadow-sm">
                    <small class="text-muted fw-bold mb-1">የሚታዘዙ እቃዎች፦</small>
                    <div class="fw-bold text-dark fs-6">
                        <i class="fa-solid fa-box-open text-primary me-1"></i>
                        <?php echo htmlspecialchars($all_product_names); ?>
                    </div>
                </div>

                <!-- ክፍያ መጠን -->
                <div class="alert alert-info border-0 shadow-sm p-3 mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span>ጠቅላላ የዶላር ዋጋ ($):</span>
                        <strong>$<?php echo number_format($total_usd, 2); ?> USD</strong>
                    </div>
                    <hr class="my-2">
                    <div class="d-flex justify-content-between fs-5 fw-bold text-primary">
                        <span>የሚከፈለው በብር (ETB):</span>
                        <span><?php echo number_format($total_etb, 2); ?> ETB</span>
                    </div>
                </div>

                <!-- የትዕዛዝ እና የክፍያ ፎርም (enctype ተጨምሯል) -->
                <form action="checkout.php" method="POST" enctype="multipart/form-data">

                    <h6 class="fw-bold text-dark border-bottom pb-2 mb-3"><i class="fa-solid fa-user me-1"></i> የደንበኛ መረጃ</h6>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small">ስም</label>
                            <input type="text" name="first_name" class="form-control" required placeholder="Abebe" value="<?php echo htmlspecialchars($_POST['first_name'] ?? $_SESSION['first_name'] ?? ''); ?>">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small">የአባት ስም</label>
                            <input type="text" name="last_name" class="form-control" required placeholder="Bikila" value="<?php echo htmlspecialchars($_POST['last_name'] ?? $_SESSION['last_name'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small">ኢሜይል</label>
                            <input type="email" name="email" class="form-control" required placeholder="abebe@gmail.com" value="<?php echo htmlspecialchars($_POST['email'] ?? $_SESSION['user_email'] ?? ''); ?>">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small">ስልክ ቁጥር</label>
                            <input type="text" name="phone" class="form-control" required placeholder="0911223344" value="<?php echo htmlspecialchars($_POST['phone'] ?? $_SESSION['user_phone'] ?? ''); ?>">
                        </div>
                    </div>

                    <h6 class="fw-bold text-dark border-bottom pb-2 my-3"><i class="fa-solid fa-location-dot me-1"></i> የመረከቢያ አድራሻ</h6>

                    <!-- ከተሞች እና ሰፈሮች Select Options -->
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-bold small">ከተማ ይምረጡ</label>
                            <select name="city" id="citySelect" class="form-select" required onchange="updateSubcities()">
                                <option value="">-- ከተማ መረጡ --</option>
                                <option value="አዲስ አበባ">አዲስ አበባ (Addis Ababa)</option>
                                <option value="አዳማ">አዳማ (Adama)</option>
                                <option value="ባህር ዳር">ባህር ዳር (Bahir Dar)</option>
                                <option value="ሐዋሳ">ሐዋሳ (Hawassa)</option>
                                <option value="መቄሌ">መቄሌ (Mekelle)</option>
                                <option value="ድሬዳዋ">ድሬዳዋ (Dire Dawa)</option>
                                <option value="ጎንደር">ጎንደር (Gondar)</option>
                                <option value="ጂማ">ጂማ (Jimma)</option>
                                <option value="ደሴ">ደሴ (Dessie)</option>
                                <option value="ወላይታ ሶዶ">ወላይታ ሶዶ (Wolaita Sodo)</option>
                                <option value="ወልቂጤ">ወልቂጤ (Wolkite)</option>
                                <option value="አርባ ምንጭ">አርባ ምንጭ (Arba Minch)</option>
                                <option value="ቢሾፍቱ">ቢሾፍቱ (Bishoftu)</option>
                                <option value="ሻሸመኔ">ሻሸመኔ (Shashemene)</option>
                                <option value="ሐረር">ሐረር (Harar)</option>
                                <option value="አክሱም">አክሱም (Axum)</option>
                                <option value="ነቀምቴ">ነቀምቴ (Nekemte)</option>
                                <option value="ሆሳዕና">ሆሳዕና (Hosaena)</option>
                                <option value="አሶሳ">አሶሳ (Assosa)</option>
                                <option value="ጋምቤላ">ጋምቤላ (Gambela)</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-bold small">ሰፈር/ክፍለ ከተማ ይምረጡ</label>
                            <select name="area" id="areaSelect" class="form-select" required>
                                <option value="">-- አስቀድመው ከተማ ይምረጡ --</option>
                            </select>
                        </div>
                    </div>

                    <h6 class="fw-bold text-dark border-bottom pb-2 my-3"><i class="fa-solid fa-credit-card me-1"></i> የክፍያ መንገድ ይምረጡ</h6>

                    <!-- ክፍያ መምረጫ Tabs/Options -->
                    <div class="accordion mb-4" id="paymentOptions">
                        <div class="accordion-item border shadow-sm">
                            <h2 class="accordion-header">
                                <button class="accordion-button fw-bold text-dark" type="button" data-bs-toggle="collapse" data-bs-target="#manualBank" aria-expanded="true">
                                    <i class="fa-solid fa-building-columns text-primary me-2"></i> ባንክ / Telebirr Direct Transfer (በዕጅ መላክ)
                                </button>
                            </h2>
                            <div id="manualBank" class="accordion-collapse collapse show" data-bs-parent="#paymentOptions">
                                <div class="accordion-body">
                                    <small class="text-muted mb-2 d-block">እባክዎን ከታች ባሉት ሂሳቦች ገንዘቡን ገቢ አድርገው Transaction ID እና የደረሰኝ ፎቶ ያስገቡ፦</small>
                                    <ul class="list-group mb-3">
                                        <li class="list-group-item d-flex justify-content-between"><span><strong>CBE:</strong> 1000763273192</span> <span class="badge bg-primary">ንግድ ባንክ</span></li>
                                        <li class="list-group-item d-flex justify-content-between"><span><strong>Telebirr:</strong> 0926680499</span> <span class="badge bg-success">ቴሌብር</span></li>
                                        <li class="list-group-item d-flex justify-content-between"><span><strong>BOA:</strong> 130571228</span> <span class="badge bg-warning text-dark">አቢሲኒያ</span></li>
                                    </ul>

                                    <!-- Transaction ID እና File Upload ጎን ለጎን -->
                                    <div class="row g-2 mb-2">
                                        <div class="col-md-6">
                                            <label class="form-label fw-bold text-danger small">Transaction ID *</label>
                                            <input type="text" name="transaction_id" class="form-control border-danger" placeholder="ምሳሌ፦ FT240818XXXX" required value="<?php echo htmlspecialchars($_POST['transaction_id'] ?? ''); ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label fw-bold small">የደረሰኝ ፎቶ (Receipt Slip)</label>
                                            <input type="file" name="receipt_image" id="receiptInput" class="form-control" accept="image/*,.pdf" onchange="previewImage(event)">
                                        </div>
                                    </div>

                                    <!-- Image Preview Box -->
                                    <div class="mt-2 text-center d-none" id="previewContainer">
                                        <small class="text-muted d-block mb-1">የተመረጠው ደረሰኝ ማሳያ፦</small>
                                        <img id="receiptPreview" src="#" alt="Receipt Preview" class="img-thumbnail" style="max-height: 150px;">
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" name="submit_order" class="btn btn-success btn-lg w-100 fw-bold shadow">
                        <i class="fa-solid fa-paper-plane me-1"></i> ትዕዛዙን አረጋግጥ እና ላክ
                    </button>

                </form>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const cityData = {
    "አዲስ አበባ": ["ቦሌ", "አራዳ", "ቂርቆስ", "የካ", "ፒያሳ", "ላፍቶ", "ኮልፌ ቀራኒዮ", "አቃቂ ቃሊቲ", "አዲስ ከተማ", "ጉለሌ", "ልደታ"],
    "አዳማ": ["01 ቀበሌ (መሃል አዳማ)", "02 ቀበሌ (ፖሊስ ኮሌጅ)", "03 ቀበሌ (ፍራንኮ)", "ቦሌ", "ቀበሌ 14", "መብራት ኃይል"],
    "ባህር ዳር": ["ቀበሌ 04 (መሃል ባህርዳር)", "ቀበሌ 11 (አባይ ማዶ)", "ዘንዘልማ", "ቀበሌ 14 (ሰባታሚት)", "ጊዮርጊስ"],
    "ሐዋሳ": ["ታቦር", "ሃዋስ", "አላሙራ", "መናኸሪያ", "ሀይቅ ዳር", "ሚሊኒየም"],
    "መቄሌ": ["ቀደምት ገበያ", "ሐደነት", "አዲ ሐቂ", "ሰሜን", "ዓይደር", "ቀሃ"],
    "ድሬዳዋ": ["ከዚራ", "መጋላ", "ሐብሾ", "ቀበሌ 02", "ቀበሌ 06", "ሰብያን"],
    "ጎንደር": ["አዘዞ", "አራዳ", "ማራኪ", "ፒያሳ", "ቀበሌ 18", "ቼቼላ"],
    "ጂማ": ["አራዳ (መሃል ጂማ)", "ጂረን", "መንድራ", "ከንቲባ", "ሳር ቤት"],
    "ደሴ": ["አራዳ", "ሆቴል ዴአን", "ሮቢት", "ፒያሳ", "ቀበሌ 03"],
    "ወላይታ ሶዶ": ["አራዳ", "ጉታራ", "ሊጋባ", "መብራት ኃይል", "ወላይታ ዲቻ"],
    "ወልቂጤ": ["ቀበሌ 01 (መሃል ወልቂጤ)", "ቀበሌ 02", "ዩኒቨርሲቲ አካባቢ", "ጉብሬ", "አዲስ ከተማ"],
    "አርባ ምንጭ": ["ሰቻ", "አልታ", "ሲቀላ", "ሊሙ", "ጫሞ"],
    "ቢሾፍቱ": ["ባቢሎን", "ሆራ", "አራዳ", "ኩሪፍቱ", "ቀበሌ 01"],
    "ሻሸመኔ": ["አራዳ", "01 ቀበሌ", "ቡልቻ", "አዋሳ መንገድ", "ጃማይካ ሰፈር"],
    "ሐረር": ["ጁጎል (Inside Jugol)", "አባዲር", "ሽንሺሌ", "ቀበሌ 13", "መብራት ኃይል"],
    "አክሱም": ["ዳሮ ሃፎ", "ሐይሎማ", "ዓይደር", "መሃል አክሱም"],
    "ነቀምቴ": ["ቀበሌ 01", "ቀበሌ 02", "ከንቲባ ሰፈር", "ባስቶ"],
    "ሆሳዕና": ["መሃል ሆሳዕና", "ሴንትራል", "ቀበሌ 02", "ቦሌ ሰፈር"],
    "አሶሳ": ["ቀበሌ 01", "ቀበሌ 02", "ቀበሌ 03", "መሃል አሶሳ"],
    "ጋምቤላ": ["ቀበሌ 01", "ቀበሌ 02", "ቀበሌ 03", "ቀበሌ 04"]
};

function updateSubcities() {
    const citySelect = document.getElementById("citySelect");
    const areaSelect = document.getElementById("areaSelect");
    const selectedCity = citySelect.value;

    areaSelect.innerHTML = '<option value="">-- ሰፈር/ክፍለ ከተማ ይምረጡ --</option>';

    if (selectedCity && cityData[selectedCity]) {
        cityData[selectedCity].forEach(function(subcity) {
            let option = document.createElement("option");
            option.value = subcity;
            option.text = subcity;
            areaSelect.appendChild(option);
        });
    }
}

function previewImage(event) {
    const reader = new FileReader();
    reader.onload = function(){
        const output = document.getElementById('receiptPreview');
        const container = document.getElementById('previewContainer');
        output.src = reader.result;
        container.classList.remove('d-none');
    };
    if (event.target.files[0]) {
        reader.readAsDataURL(event.target.files[0]);
    }
}
</script>

</body>
</html>