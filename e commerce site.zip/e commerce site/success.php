<?php
session_start();
require_once 'config.php';

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

if ($order_id <= 0) {
    header("Location: index.php");
    exit();
}

// የትዕዛዙን መረጃ ከዳታቤዝ ማውጣት
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    echo "ትዕዛዙ አልተገኘም!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <title>ትዕዛዝዎ ተልኳል</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center">
            <div class="card shadow border-0 p-4">
                <div class="text-success mb-3">
                    <i class="fa-solid fa-circle-check fa-4x"></i>
                </div>
                <h3 class="fw-bold text-success">እናመሰግናለን!</h3>
                <p class="text-muted">ትዕዛዝዎ በተሳካ ሁኔታ ተልኳል። ክፍያዎ ከተረጋገጠ በኋላ እቃዎ ይላካል።</p>

                <div class="bg-light p-3 rounded mb-4 text-start border">
                    <p class="mb-1"><strong>የትዕዛዝ ቁጥር (Order ID):</strong> #<?php echo $order['id']; ?></p>
                    <p class="mb-1"><strong>ስም:</strong> <?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></p>
                    <p class="mb-1"><strong>ጠቅላላ ክፍያ:</strong> <?php echo number_format($order['amount'], 2); ?> ETB</p>
                    <p class="mb-0"><strong>የመቀበያ ኮድ (Pickup Code):</strong> <span class="badge bg-primary fs-6"><?php echo $order['pickup_code']; ?></span></p>
                </div>

                <!-- 🔗 የ Customer Invoice Link -->
                <div class="d-grid gap-2">
                    <a href="invoice.php?order_id=<?php echo $order['id']; ?>" target="_blank" class="btn btn-outline-primary btn-lg fw-bold">
                        <i class="fa-solid fa-file-invoice me-2"></i> Invoice (ደረሰኝ) ይመልከቱ / Print ያድርጉ
                    </a>
                    <a href="index.php" class="btn btn-primary mt-2">ወደ ዋና ገፅ ተመለስ</a>
                </div>

            </div>
        </div>
    </div>
</div>

</body>
</html>