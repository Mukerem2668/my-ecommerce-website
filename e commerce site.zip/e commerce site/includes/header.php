<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MUKKA SHOP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* የ Google Translate አሞሌን (Top Banner) ሙሉ በሙሉ መደበቂያ */
        .goog-te-banner-frame, .skiptranslate, iframe.skiptranslate {
            display: none !important;
        }
        body {
            top: 0px !important;
        }
        .goog-te-gadget-icon {
            display: none !important;
        }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold text-primary" href="index.php">MUKKA <span class="text-white">SHOP</span></a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto align-items-center">
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="product.php">Products</a></li>
        
        <!-- Language Toggle Switch Container -->
        <li class="nav-item ms-lg-3 my-2 my-lg-0">
            <div class="d-flex align-items-center bg-light text-dark border px-3 py-1 rounded-pill">
                <span class="small fw-bold me-2 text-primary" id="lang-en-label">EN</span>
                <div class="form-check form-switch mb-0">
                    <input class="form-check-input" type="checkbox" role="switch" id="customLangToggle" style="cursor: pointer;" onchange="changeLanguage(this.checked)">
                </div>
                <span class="small fw-bold ms-1 text-muted" id="lang-am-label">አማ</span>
            </div>
        </li>
      </ul>

      <ul class="navbar-nav ms-auto align-items-center">
        <!-- Cart Badge -->
        <li class="nav-item me-3">
          <a class="nav-link text-white position-relative" href="cart.php">
            <i class="fa-solid fa-cart-shopping fs-5"></i>
            <?php if (!empty($_SESSION['cart'])): ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    <?php echo array_sum($_SESSION['cart']); ?>
                </span>
            <?php endif; ?>
          </a>
        </li>

        <!-- User Authentication -->
        <?php if (isset($_SESSION['user_id'])): ?>
            <li class="nav-item me-3">
                <span class="text-warning fw-bold">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</span>
            </li>
            <li class="nav-item">
                <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
            </li>
        <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
            <li class="nav-item"><a class="btn btn-primary btn-sm ms-2" href="register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- ድብቅ የ Google Translate ኤለመንት -->
<div id="google_translate_element" style="display:none;"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'en',
        includedLanguages: 'en,am',
        autoDisplay: false
    }, 'google_translate_element');

    // ገጹ ሲከፈት ቀደሞ የተመረጠው ቋንቋ ካለ Checkbox-ን ON ወይም OFF ያደርጋል
    setTimeout(function() {
        var googCookie = getCookie('googtrans');
        if (googCookie && googCookie.includes('/am')) {
            document.getElementById('customLangToggle').checked = true;
            updateLabelColors(true);
        } else {
            document.getElementById('customLangToggle').checked = false;
            updateLabelColors(false);
        }
    }, 500);
}

function changeLanguage(isAmharic) {
    var langCode = isAmharic ? 'am' : 'en';
    
    // Cookie በመቀየር ገጹ በ Google Translate እንዲተረጎም ማድረግ
    document.cookie = "googtrans=/en/" + langCode + "; path=/;";
    document.cookie = "googtrans=/en/" + langCode + "; domain=" + window.location.hostname + "; path=/;";
    
    updateLabelColors(isAmharic);
    
    // ገጹን አዲስ በማድረግ ትርጉሙ እንዲተገበር ማድረግ
    window.location.reload();
}

function updateLabelColors(isAmharic) {
    var enLabel = document.getElementById('lang-en-label');
    var amLabel = document.getElementById('lang-am-label');
    
    if (isAmharic) {
        enLabel.className = 'small fw-bold me-2 text-muted';
        amLabel.className = 'small fw-bold ms-1 text-primary';
    } else {
        enLabel.className = 'small fw-bold me-2 text-primary';
        amLabel.className = 'small fw-bold ms-1 text-muted';
    }
}

function getCookie(name) {
    var cname = name + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(cname) == 0) return c.substring(cname.length, c.length);
    }
    return "";
}
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>