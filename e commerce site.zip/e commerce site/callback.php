<?php
// callback.php
require_once 'config.php';

// 1. ከ Chapa በስተጀርባ (Webhook) የሚላከውን የ JSON መረጃ መቀበል
$input = file_get_contents('php://input');
$event = json_decode($input, true);

// 2. የ Transaction Reference (tx_ref) መኖሩን ማረጋገጥ
$tx_ref = null;

if (isset($event['trx_ref'])) {
    $tx_ref = $event['trx_ref'];
} elseif (isset($event['tx_ref'])) {
    $tx_ref = $event['tx_ref'];
} elseif (isset($_GET['trx_ref'])) {
    $tx_ref = $_GET['trx_ref'];
}

if ($tx_ref) {

    // 3. Chapa API ላይ ክፍያው በእርግጥም መፈጸሙን ማረጋገጥ (Verification)
    $ch = curl_init(CHAPA_BASE_URL . '/verify/' . $tx_ref);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . CHAPA_SECRET_KEY
    ]);

    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
        http_response_code(500);
        die("cURL Error: " . $err);
    }

    $res = json_decode($response, true);

    // 4. ክፍያው ከተረጋገጠ (Status = success ከሆነ)
    if (isset($res['status']) && $res['status'] === 'success' && $res['data']['status'] === 'success') {
        
        // Chapa የከፈለበትን የክፍያ መንገድ ይሰጠናል (telebirr, cbebirr, card...)
        $payment_method = isset($res['data']['method']) ? $res['data']['method'] : 'unknown';

        // 5. በዳታቤዝ ውስጥ የትዕዛዙን Status እና Payment Method ማዘመን
        $stmt = $conn->prepare("UPDATE orders SET status = 'Paid', payment_method = ? WHERE tx_ref = ?");
        $stmt->bind_param("ss", $payment_method, $tx_ref);
        
        if ($stmt->execute()) {
            http_response_code(200); // ለ Chapa መልእክቱ በትክክል እንደደረሰን መመለስ
            echo json_encode(["status" => "success", "message" => "Order updated to Paid"]);
        } else {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Database update failed"]);
        }

    } else {
        http_response_code(400);
        echo json_encode(["status" => "failed", "message" => "Payment verification failed"]);
    }

} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "No tx_ref provided"]);
}
?>