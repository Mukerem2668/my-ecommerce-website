<?php
ob_start();
session_start();
include 'config/db.php';

$message = '';

if (isset($_POST['register'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = '<div class="alert alert-danger">እባክዎን ትክክለኛ የኢሜይል አድራሻ ያስገቡ!</div>';
    } else {
        $email_escaped = $conn->real_escape_string($email);
        $check_email = $conn->query("SELECT id FROM users WHERE email='$email_escaped'");
        
        if ($check_email && $check_email->num_rows > 0) {
            $message = '<div class="alert alert-danger">ይህ ኢሜይል ቀደም ብሎ ተመዝግቧል!</div>';
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $name_escaped = $conn->real_escape_string($name);
            
            $sql = "INSERT INTO users (name, email, password, role, is_verified) 
                    VALUES ('$name_escaped', '$email_escaped', '$hashed_password', 'customer', 1)";
            
            if ($conn->query($sql)) {
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_role'] = 'customer';

                header("Location: index.php");
                exit();
            } else {
                $message = '<div class="alert alert-danger">የምዝገባ ስህተት ተከስቷል፦ ' . $conn->error . '</div>';
            }
        }
    }
}

include 'includes/header.php';
?>

<!-- የ Google JavaScript SDK -->
<script src="https://accounts.google.com/gsi/client" async defer></script>

<div class="container my-5" style="max-width: 500px;">
    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
            <h3 class="fw-bold text-center mb-4">የደንበኛ መመዝገቢያ</h3>
            <?php echo $message; ?>
            
            <form action="register.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">ሙሉ ስም</label>
                    <input type="text" name="name" class="form-control" required placeholder="ሙሉ ስምዎን ያስገቡ">
                </div>
                <div class="mb-3">
                    <label class="form-label">ኢሜይል</label>
                    <input type="email" name="email" class="form-control" required placeholder="example@gmail.com">
                </div>
                <div class="mb-3">
                    <label class="form-label">ሚስጥር ቁጥር</label>
                    <input type="password" name="password" class="form-control" required placeholder="******">
                </div>

                <button type="submit" name="register" class="btn btn-primary w-100 py-2 fw-bold">መዝግብ</button>
            </form>

            <div class="text-center my-3">
                <span class="text-muted small">ወይም</span>
            </div>

            <!-- የ Google Sign-Up Button (የራሰህ Client ID ተክቷል) -->
            <div class="my-3 text-center">
                <div id="g_id_onload"
                     data-client_id="1041851260433-136ekh43jbgtt2iumu7mit7uo5u8df39.apps.googleusercontent.com"
                     data-callback="handleCredentialResponse">
                </div>
    <div class="g_id_signin d-flex justify-content-center" 
     data-type="standard" 
     data-shape="rectangular" 
     data-theme="outline" 
     data-text="signup_with" 
     data-size="large" 
     data-width="100%">
</div>
            </div>

            <hr>
            <p class="text-center mb-0">አካውንት አለዎት? <a href="login.php" class="fw-bold">ይግቡ</a></p>
        </div>
    </div>
</div>

<!-- መረጃውን ወደ google-login.php መላኪያ Script -->
<script>
function handleCredentialResponse(response) {
    fetch('google-login.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'credential=' + encodeURIComponent(response.credential)
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            window.location.href = 'index.php';
        } else {
            alert('የ Google ምዝገባ አልተሳካም፦ ' + data.message);
        }
    })
    .catch(err => console.error('Error:', err));
}
</script>

<?php include 'includes/footer.php'; ?>