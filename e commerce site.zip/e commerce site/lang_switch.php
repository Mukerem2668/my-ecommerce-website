<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. ቋንቋ መቀየር
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = ($_GET['lang'] === 'am') ? 'am' : 'en';
}

// 2. ነባሪ ቋንቋ ማዘጋጀት (ያልተመረጠ ከሆነ እንግሊዝኛ)
$lang = $_SESSION['lang'] ?? 'en';

// 3. የሁሉም ቃላትና አረፍተ ነገሮች መዝገበ-ቃላት (Translations Array)
$translations = [
    'en' => [
        // Sidebar & Navbar
        'dashboard' => 'Dashboard',
        'products' => 'Products',
        'add_product' => 'Add Product',
        'orders' => 'Orders',
        'customer_rating' => 'Customer Ratings',
        'sales_analytics' => 'Sales Analytics',
        'settings' => 'Settings',
        'view_site' => 'View Site',
        'logout' => 'Logout',
        'admin_control' => 'Admin Control Center',
        
        // Customer Pages
        'welcome_title' => 'Welcome to MyStore',
        'welcome_subtitle' => 'Discover the best quality products',
        'search_placeholder' => 'Search products...',
        'all_categories' => 'All Categories',
        'search_btn' => 'Search',
        'my_account' => 'My Profile',
        'wishlist' => 'Wishlist',
        'track_order' => 'Track Order',
        'product_list' => 'Product Collection',
        'add_to_cart' => 'Cart',
        'no_products' => 'No products found',
        'price' => 'Price',

        // Dashboard Labels
        'total_sales' => 'Total Sales',
        'total_orders' => 'Total Orders',
        'total_products' => 'Total Products',
        'total_customers' => 'Customers',
        'low_stock' => 'Low Stock Alert',
        'stock_warning' => 'items are out of stock or running low!'
    ],
    'am' => [
        // Sidebar & Navbar
        'dashboard' => 'ዳሽቦርድ',
        'products' => 'እቃዎች',
        'add_product' => 'እቃ ጨምር',
        'orders' => 'ትዕዛዞች',
        'customer_rating' => 'የደንበኞች አስተያየት',
        'sales_analytics' => 'የሽያጭ ትንተና',
        'settings' => 'ሴቲንግ',
        'view_site' => 'ሳይቱን እይ',
        'logout' => 'ውጣ',
        'admin_control' => 'የአድሚን መቆጣጠሪያ',
        
        // Customer Pages
        'welcome_title' => 'እንኳን ወደ MyStore በደህና መጡ',
        'welcome_subtitle' => 'ምርጥ እቃዎችን በጥራት ያግኙ',
        'search_placeholder' => 'የእቃ ስም ፈልግ...',
        'all_categories' => 'ሁሉንም ካቴጎሪዎች',
        'search_btn' => 'ፈልግ',
        'my_account' => 'የኔ አካውንት',
        'wishlist' => 'ምኞት ዝርዝር',
        'track_order' => 'ትዕዛዝ ተከታተል',
        'product_list' => 'የእቃዎች ዝርዝር',
        'add_to_cart' => 'ቅርጫት',
        'no_products' => 'ምንም የተገኘ እቃ የለም',
        'price' => 'ዋጋ',

        // Dashboard Labels
        'total_sales' => 'ጠቅላላ ሽያጭ',
        'total_orders' => 'የትዕዛዞች ብዛት',
        'total_products' => 'የእቃዎች ብዛት',
        'total_customers' => 'ደንበኞች',
        'low_stock' => 'የ Stock ማስጠንቀቂያ',
        'stock_warning' => 'እቃዎች አልቀዋል ወይም መጠናቸው አነስተኛ ነው!'
    ]
];

// 4. ቃላትን በቀላሉ ለመጥራት የሚያገለግል Function
function __($key) {
    global $translations, $lang;
    return $translations[$lang][$key] ?? $key;
}

// አቅጣጫ ማስቀየሪያ (Redirect)
if (isset($_GET['lang'])) {
    $redirect = $_SERVER['HTTP_REFERER'] ?? 'index.php';
    header("Location: " . $redirect);
    exit();
}
?>