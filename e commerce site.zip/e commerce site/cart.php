<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'config/db.php';

// 1. ደንበኛው Login ማድረጉን ማረጋገጥ
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=login_required");
    exit;
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

$cart_error = "";

// 2. ወደ ቅርጫት መጨመር (Add to Cart With Stock Check)
if (isset($_POST['add_to_cart'])) {
    $product_id = intval($_POST['product_id']);
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

    // የላቀ Stock መኖሩን ዳታቤዝ ላይ ማረጋገጥ
    $stmt = $conn->prepare("SELECT stock, name FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $prod = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $current_in_cart = $_SESSION['cart'][$product_id] ?? 0;
    $total_requested = $current_in_cart + $quantity;

    if ($prod && $prod['stock'] >= $total_requested) {
        $_SESSION['cart'][$product_id] = $total_requested;
    } else {
        $_SESSION['stock_error'] = "ይቅርታ! '" . ($prod['name'] ?? 'እቃ') . "' የተጠየቀውን ያህል Stock የለውም። የቀረው ብዛት፦ " . ($prod['stock'] ?? 0);
    }
    header("Location: cart.php");
    exit;
}

// 3. የሕብረ-እቃ ብዛት ማዘመን (Update Quantity With Stock Check)
if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantities'] as $product_id => $quantity) {
        $product_id = intval($product_id);
        $quantity = intval($quantity);
        
        if ($quantity > 0) {
            $stmt = $conn->prepare("SELECT stock, name FROM products WHERE id = ?");
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $prod = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($prod && $prod['stock'] >= $quantity) {
                $_SESSION['cart'][$product_id] = $quantity;
            } else {
                $_SESSION['stock_error'] = "ይቅርታ! '" . ($prod['name'] ?? 'እቃ') . "' በቂ Stock የለውም። የቀረው ብዛት፦ " . ($prod['stock'] ?? 0);
            }
        } else {
            unset($_SESSION['cart'][$product_id]);
        }
    }
    header("Location: cart.php");
    exit;
}

// 4. አንድን እቃ ከቅርጫት ማስወገድ (Remove Item)
if (isset($_GET['remove'])) {
    $remove_id = intval($_GET['remove']);
    unset($_SESSION['cart'][$remove_id]);
    header("Location: cart.php");
    exit;
}

// 5. ቅርጫቱን ሙሉ በሙሉ ማፅዳት (Clear All)
if (isset($_GET['clear']) && $_GET['clear'] === 'all') {
    $_SESSION['cart'] = array();
    header("Location: cart.php");
    exit;
}

// 6. Checkout ከመሄዱ በፊት በቂ Stock መኖሩን ማረጋገጥ
$has_stock_issue = false;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $p_id => $qty) {
        $stmt_chk = $conn->prepare("SELECT stock, name FROM products WHERE id = ?");
        $stmt_chk->bind_param("i", $p_id);
        $stmt_chk->execute();
        $p_res = $stmt_chk->get_result()->fetch_assoc();
        $stmt_chk->close();

        if (!$p_res || $p_res['stock'] < $qty) {
            $has_stock_issue = true;
            $cart_error = "ይቅርታ! በቅርጫትዎ ውስጥ ያሉ የተወሰኑ እቃዎች በቂ Stock የላቸውም። እባክዎን ብዛታቸውን ይቀንሱ ወይም ከቅርጫት ያስወግዷቸው!";
            break;
        }
    }
}

include 'includes/header.php';
?>

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold m-0"><i class="fa-solid fa-cart-shopping me-2"></i>የእርስዎ ቅርጫት (Shopping Cart)</h3>
        <?php if (!empty($_SESSION['cart'])): ?>
            <a href="cart.php?clear=all" class="btn btn-outline-danger btn-sm" onclick="return confirm('ቅርጫቱን ሙሉ በሙሉ ማፅዳት ይፈልጋሉ?');">
                <i class="fa-solid fa-trash-can me-1"></i> ቅርጫቱን አፅዳ
            </a>
        <?php endif; ?>
    </div>

    <!-- Stock Error Alerts -->
    <?php 
    if (isset($_SESSION['stock_error'])) {
        echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2"></i>' . htmlspecialchars($_SESSION['stock_error']) . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['stock_error']);
    }

    if (!empty($cart_error)) {
        echo '<div class="alert alert-danger" role="alert">
                <i class="fa-solid fa-circle-exclamation me-2"></i>' . htmlspecialchars($cart_error) . '
              </div>';
    }
    ?>

    <?php if (!empty($_SESSION['cart'])): ?>
        <form action="cart.php" method="POST">
            <div class="table-responsive">
                <table class="table table-hover align-middle bg-white shadow-sm border">
                    <thead class="table-light">
                        <tr>
                            <th>እቃ</th>
                            <th>ዋጋ</th>
                            <th style="width: 140px;">ብዛት</th>
                            <th>Stock ሁኔታ</th>
                            <th>ጠቅላላ</th>
                            <th class="text-center">ተግባር</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $grand_total = 0;
                        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");

                        foreach ($_SESSION['cart'] as $id => $qty): 
                            $stmt->bind_param("i", $id);
                            $stmt->execute();
                            $res = $stmt->get_result();

                            if ($res && $res->num_rows > 0):
                                $item = $res->fetch_assoc();
                                $subtotal = $item['price'] * $qty;
                                $grand_total += $subtotal;
                                $available_stock = intval($item['stock']);
                                $is_stock_exceeded = ($qty > $available_stock);
                        ?>
                        <tr class="<?php echo $is_stock_exceeded ? 'table-danger' : ''; ?>">
                            <td>
                                <strong><?php echo htmlspecialchars($item['name']); ?></strong>
                            </td>
                            <td>$<?php echo number_format($item['price'], 2); ?></td>
                            <td>
                                <input type="number" name="quantities[<?php echo $id; ?>]" value="<?php echo $qty; ?>" min="1" max="<?php echo $available_stock; ?>" class="form-control form-control-sm text-center <?php echo $is_stock_exceeded ? 'is-invalid' : ''; ?>">
                            </td>
                            <td>
                                <?php if ($is_stock_exceeded): ?>
                                    <span class="badge bg-danger">ከስቶክ በላይ (ቀሪ፦ <?php echo $available_stock; ?>)</span>
                                <?php else: ?>
                                    <span class="badge bg-success">In Stock (<?php echo $available_stock; ?>)</span>
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold">$<?php echo number_format($subtotal, 2); ?></td>
                            <td class="text-center">
                                <a href="cart.php?remove=<?php echo $id; ?>" class="btn btn-sm btn-outline-danger" title="አስወግድ">
                                    <i class="fa-solid fa-xmark"></i>
                                </a>
                            </td>
                        </tr>
                        <?php 
                            endif; 
                        endforeach; 
                        $stmt->close();
                        ?>
                        <tr class="table-light">
                            <td colspan="4" class="fw-bold text-end">ጠቅላላ ድምር:</td>
                            <td colspan="2" class="fw-bold text-primary fs-5">$<?php echo number_format($grand_total, 2); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-between align-items-center mt-3">
                <button type="submit" name="update_cart" class="btn btn-outline-primary">
                    <i class="fa-solid fa-rotate me-1"></i> ብዛት አዘምን (Update)
                </button>
                
                <?php if ($has_stock_issue): ?>
                    <button type="button" class="btn btn-secondary px-4" disabled title="እባክዎን ከስቶክ በላይ የሆኑትን እቃዎች ያስተካክሉ">
                        ክፈያ ጨርስ (Checkout) <i class="fa-solid fa-arrow-right ms-1"></i>
                    </button>
                <?php else: ?>
                    <a href="checkout.php" class="btn btn-success px-4">
                        ክፈያ ጨርስ (Checkout) <i class="fa-solid fa-arrow-right ms-1"></i>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    <?php else: ?>
        <div class="alert alert-info text-center p-4">
            <h5>ቅርጫትዎ ባዶ ነው!</h5>
            <p class="mb-3 text-muted">የሚፈልጉትን እቃ መርጠው ወደ ቅርጫት ያስገቡ።</p>
            <a href="product.php" class="btn btn-primary"><i class="fa-solid fa-store me-1"></i> እቃዎችን ይመልከቱ</a>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>