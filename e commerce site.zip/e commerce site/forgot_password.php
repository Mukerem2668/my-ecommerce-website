<?php
session_start();
require_once __DIR__ . '/config/db.php'; 

date_default_timezone_set('Africa/Addis_Ababa');

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "እባክዎን ትክክለኛ ኢሜይል ያስገቡ!";
        $message_type = "danger";
    } else {
        // 1. ኢሜይሉ በ users table ውስጥ መኖሩን ማረጋገጥ
        $stmt = $conn->prepare("SELECT id, name FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            // 2. ባለ 6-አሃዝ Random OTP ኮድ ማዘጋጀት
            $reset_code = sprintf("%06d", mt_rand(100000, 999999));
            $expires_at = date('Y-m-d H:i:s', time() + (15 * 60));

            // ነባር ኮዶችን ማጽዳት
            $del_stmt = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
            $del_stmt->bind_param("s", $email);
            $del_stmt->execute();

            // አዲሱን ኮድ ማስገባት
            $ins_stmt = $conn->prepare("INSERT INTO password_resets (email, code, expires_at) VALUES (?, ?, ?)");
            $ins_stmt->bind_param("sss", $email, $reset_code, $expires_at);
            $ins_stmt->execute();

            // 3. በ Brevo API ኢሜይል መላክ
            $brevo_api_key = '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'; 

            $email_data = [
                'sender' => [
                    'name'  => 'E-Commerce Store',
                    'email' => 'mukerem26@gmail.com'
                ],
                'to' => [
                    [
                        'email' => $email,
                        'name'  => $user['name'] ?? 'Customer'
                    ]
                ],
                'subject' => 'የይለፍ ቃል መቀየሪያ ኮድ - ' . $reset_code,
                'htmlContent' => "
                <div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ddd; max-width: 500px;'>
                    <h2 style='color: #0d6efd;'>የይለፍ ቃል ማረጋገጫ ኮድ</h2>
                    <p>ሰላም " . htmlspecialchars($user['name'] ?? '') . "፣</p>
                    <p>የይለፍ ቃልዎን ለመቀየር የሚከተለውን ማረጋገጫ ኮድ ይጠቀሙ፦</p>
                    <div style='background-color: #f4f4f4; text-align: center; font-size: 32px; font-weight: bold; letter-spacing: 5px; padding: 15px; margin: 20px 0; border-radius: 5px; color: #0d6efd;'>
                        {$reset_code}
                    </div>
                    <p>ይህ ኮድ የሚያገለግለው ለ <strong>15 ደቂቃዎች</strong> ብቻ ነው።</p>
                    <hr style='border: none; border-top: 1px solid #eee;'>
                    <small style='color: #777;'>ጥያቄውን እርስዎ ካላቀረቡ እባክዎን ይህንን ኢሜይል ችላ ይበሉት።</small>
                </div>"
            ];

            $ch = curl_init('https://api.brevo.com/v3/smtp/email');
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'api-key: ' . $brevo_api_key,
                'Content-Type: application/json',
                'Accept: application/json'
            ]);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($email_data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($http_code === 201 || $http_code === 200) {
                $_SESSION['reset_email'] = $email;
                header("Location: verify_code.php");
                exit;
            } else {
                $message = "ኢሜይል መላክ አልተቻለም። እባክዎን Brevo ላይ የተመዘገቡበትን ኢሜይል ማስተካከልዎን ያረጋግጡ።";
                $message_type = "danger";
            }

        } else {
            $message = "!ኢሜይል መላክ አልተቻለም።";
            $message_type = "danger";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>የይለፍ ቃል መረሳሻ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light d-flex align-items-center justify-content-center min-vh-100">

<div class="card shadow border-0 p-4" style="max-width: 400px; width: 100%;">
    <div class="text-center mb-4">
        <i class="fa-solid fa-envelope-circle-check fa-3x text-primary mb-2"></i>
        <h4 class="fw-bold">ኮድ በኢሜይል ላክ</h4>
        <p class="text-muted small">የይለፍ ቃል መቀየሪያ ኮድ እንዲላክልዎት ኢሜይልዎን ያስገቡ።</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <form action="" method="POST" class="mb-3">
        <div class="mb-3">
            <label class="form-label fw-bold">ኢሜይል (Email)</label>
            <input type="email" name="email" class="form-control" placeholder="example@mail.com" required>
        </div>

        <button type="submit" class="btn btn-primary w-100 fw-bold py-2">
            <i class="fa-solid fa-paper-plane me-1"></i> ኮድ ላክ
        </button>
    </form>

    <div class="text-center pt-2 border-top">
        <a href="login.php" class="text-decoration-none fw-semibold text-secondary small hover-primary">
            <i class="fa-solid fa-arrow-left me-1"></i> ወደ መግቢያ ገፅ ተመለስ (Back to Login)
        </a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>