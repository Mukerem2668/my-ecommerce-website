<?php
session_start();
include '../config/db.php';

// Admin መሆኑን ማረጋገጥ
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // የፎቶውን path ማወቅ
    $result = $conn->query("SELECT image FROM products WHERE id = $product_id");
    if ($result && $result->num_rows > 0) {
        $product = $result->fetch_assoc();
        
        // ፎቶውን ከ uploads/ ማጥፋት
        if (file_exists("../" . $product['image'])) {
            unlink("../" . $product['image']);
        }

        // ከ Database ማጥፋት
        $conn->query("DELETE FROM products WHERE id = $product_id");
    }
}

header("Location: products.php");
exit;
?>