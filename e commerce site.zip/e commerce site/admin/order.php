<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../config/db.php'; 

// በ Sidebarህ ከተጠቀመው Session variable ጋር ማስተካከል
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$message = "";
if (isset($_SESSION['msg'])) {
    $message = $_SESSION['msg'];
    unset($_SESSION['msg']);
}

// ---------------------------------------------------------
// 1. የትዕዛዝ ማጥፊያ (Delete Order) Action
// ---------------------------------------------------------
if (isset($_POST['delete_order'])) {
    $delete_id = intval($_POST['order_id']);
    if ($delete_id > 0) {
        $del_stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
        $del_stmt->bind_param("i", $delete_id);
        if ($del_stmt->execute()) {
            $_SESSION['msg'] = "ትዕዛዝ #" . $delete_id . " በትክክል ተሰርዟል!";
        } else {
            $_SESSION['msg'] = "ስህተት፦ " . $conn->error;
        }
        $del_stmt->close();
    }
    $query_params = $_GET;
    $redirect_url = $_SERVER['PHP_SELF'] . (!empty($query_params) ? '?' . http_build_query($query_params) : '');
    header("Location: " . $redirect_url);
    exit;
}

// ---------------------------------------------------------
// 2. የትዕዛዙን Status እና Admin Message መቀየር፣ Stock ማስተካከል እና ኢሜይል መላክ
// ---------------------------------------------------------
if (isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = trim($_POST['status']);
    $admin_msg = trim($_POST['admin_message'] ?? '');

    if ($order_id > 0 && !empty($new_status)) {
        // የደንበኛውን መረጃ እና የቀደመውን Status ከ Database መፈለግ
        $user_stmt = $conn->prepare("SELECT email, first_name, last_name, product_name, status FROM orders WHERE id = ?");
        $user_stmt->bind_param("i", $order_id);
        $user_stmt->execute();
        $user_res = $user_stmt->get_result();
        $customer = $user_res->fetch_assoc();
        $user_stmt->close();

        if ($customer) {
            $old_status = strtolower(trim($customer['status'] ?? ''));
            $target_status = strtolower(trim($new_status));

            // ሀ. ትዕዛዙ ከተሰረዘ/ከተቃወመ (Failed/Rejected/Cancelled) እና ቀደም ሲል ካልተሰረዘ Stock ን መመለስ
            if (in_array($target_status, ['failed', 'rejected', 'cancelled']) && !in_array($old_status, ['failed', 'rejected', 'cancelled'])) {
                
                $raw_products = $customer['product_name'] ?? '';
                $items = explode(',', $raw_products);

                foreach ($items as $item) {
                    if (preg_match('/^(.*?)\s*\(x(\d+)\)/u', trim($item), $matches)) {
                        $p_name = trim($matches[1]);
                        $qty = intval($matches[2]);

                        $restore_stmt = $conn->prepare("UPDATE products SET stock = stock + ? WHERE name = ?");
                        $restore_stmt->bind_param("is", $qty, $p_name);
                        $restore_stmt->execute();
                        $restore_stmt->close();
                    }
                }
            }

            // ለ. Database ማዘመን
            $stmt = $conn->prepare("UPDATE orders SET status = ?, admin_message = ? WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("ssi", $new_status, $admin_msg, $order_id);
                if ($stmt->execute()) {
                    
                    // ሐ. ለደንበኛው ኢሜይል የሚላክበት ክፍል
                    if (!empty($customer['email'])) {
                        $to = $customer['email'];
                        $subject = "የትዕዛዝዎ ሁኔታ ተቀይሯል - Order #" . $order_id;
                        $customer_name = $customer['first_name'] . ' ' . $customer['last_name'];
                        
                        $email_body = "ሰላም " . htmlspecialchars($customer_name) . ",\n\n";
                        $email_body .= "የትዕዛዝ ቁጥር #" . $order_id . " ሁኔታ በትክክል ተዘምኗል።\n";
                        $email_body .= "አዲስ ሁኔታ (Status)፦ " . $new_status . "\n";
                        
                        if (!empty($admin_msg)) {
                            $email_body .= "ከአድሚን የተላከ መልእክት፦\n" . $admin_msg . "\n\n";
                        }
                        
                        $email_body .= "እናመሰግናለን!";
                        $headers = "From: no-reply@yourdomain.com\r\n" .
                                   "Reply-To: support@yourdomain.com\r\n" .
                                   "X-Mailer: PHP/" . phpversion();

                        @mail($to, $subject, $email_body, $headers);
                    }

                    $_SESSION['msg'] = "የትዕዛዙ ሁኔታ ወደ '{$new_status}' በትክክል ተቀይሯል!";
                } else {
                    $_SESSION['msg'] = "ስህተት፦ " . $conn->error;
                }
                $stmt->close();
            }
        }
    }

    $query_params = $_GET;
    $redirect_url = $_SERVER['PHP_SELF'] . (!empty($query_params) ? '?' . http_build_query($query_params) : '');
    header("Location: " . $redirect_url);
    exit;
}

// ---------------------------------------------------------
// 3. ከ 2025 ጀምሮ ያሉትን ሁሉንም ወራት ዝርዝር ማዘጋጀት
// ---------------------------------------------------------
$start_year = 2025;
$current_year = intval(date('Y'));
$all_months_options = [];

// ከቅርብ ዓመት ወደ ኋላ (2026, 2025...) እና ከታህሳስ ወደ ጥር
for ($yr = $current_year; $yr >= $start_year; $yr--) {
    for ($m = 12; $m >= 1; $m--) {
        $m_padded = str_pad($m, 2, '0', STR_PAD_LEFT);
        $ym_key = "{$yr}-{$m_padded}";
        $label = date('F Y', strtotime("{$ym_key}-01"));
        $all_months_options[$ym_key] = $label;
    }
}

// ---------------------------------------------------------
// 4. የተመረጠውን ወር እና Search term መቀበል
// ---------------------------------------------------------
$selected_month = isset($_GET['month']) ? trim($_GET['month']) : '';
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

// ---------------------------------------------------------
// 5. የትዕዛዞች SQL Query ማዘጋጀት (Filter & Search ጨምሮ)
// ---------------------------------------------------------
$sql = "SELECT * FROM orders WHERE 1=1";
$params = [];
$types = "";

if (!empty($selected_month)) {
    $sql .= " AND DATE_FORMAT(created_at, '%Y-%m') = ?";
    $params[] = $selected_month;
    $types .= "s";
}

if (!empty($search_query)) {
    $sql .= " AND (first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR tx_ref LIKE ? OR pickup_code LIKE ?)";
    $search_param = "%" . $search_query . "%";
    for ($i = 0; $i < 5; $i++) {
        $params[] = $search_param;
        $types .= "s";
    }
}

$sql .= " ORDER BY id DESC";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$orders = $stmt->get_result();

// ---------------------------------------------------------
// 6. የወሩን አጠቃላይ ድምር ለማስላት
// ---------------------------------------------------------
$total_monthly_amount = 0;
$total_orders_count = 0;
$orders_data = [];

if ($orders && $orders->num_rows > 0) {
    while ($row = $orders->fetch_assoc()) {
        $orders_data[] = $row;
        $total_orders_count++;
        
        $status = strtolower(trim($row['status'] ?? ''));
        if (!in_array($status, ['failed', 'rejected', 'cancelled'])) {
            $total_monthly_amount += floatval($row['amount'] ?? 0);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Orders Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container-fluid px-4 my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold m-0"><i class="fa-solid fa-truck-ramp-box me-2"></i> ትዕዛዞች ማኔጅመንት</h2>
        <a href="dashboard.php" class="btn btn-outline-dark"><i class="fa-solid fa-gauge me-1"></i> Dashboard</a>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info alert-dismissible fade show shadow-sm">
            <?php echo htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- የወር እና የፍለጋ (Search) ማጣሪያ -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-3">
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="GET" class="row g-3 align-items-center">
                <div class="col-md-4">
                    <label class="form-label small text-muted fw-bold mb-1">በወር አጣራ (ከ 2025 ጀምሮ)፦</label>
                    <select name="month" class="form-select" onchange="this.form.submit()">
                        <option value="">ሁሉንም ወራት አሳይ</option>
                        <?php foreach ($all_months_options as $ym_val => $ym_label): ?>
                            <option value="<?php echo $ym_val; ?>" <?php echo ($selected_month === $ym_val) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($ym_label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-5">
                    <label class="form-label small text-muted fw-bold mb-1">ፈልግ (በስም፣ በስልክ፣ በRef/Pickup Code)፦</label>
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="እዚህ ላይ ይፃፉ..." value="<?php echo htmlspecialchars($search_query); ?>">
                        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-magnifying-glass"></i> ፈልግ</button>
                    </div>
                </div>

                <div class="col-md-3">
                    <label class="form-label small text-muted fw-bold mb-1">&nbsp;</label>
                    <div>
                        <a href="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="btn btn-outline-secondary w-100">
                            <i class="fa-solid fa-rotate-left me-1"></i> Filter አፅዳ
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- አጠቃላይ የወሩ ስታቲስቲክስ ካርዶች -->
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm bg-primary text-white p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase small mb-1">የተመረጠው ወር አጠቃላይ ትዕዛዞች</h6>
                        <h3 class="fw-bold mb-0"><?php echo $total_orders_count; ?></h3>
                    </div>
                    <i class="fa-solid fa-cart-shopping fa-2x opacity-50"></i>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card border-0 shadow-sm bg-success text-white p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-uppercase small mb-1">የተመረጠው ወር አጠቃላይ ገቢ (ETB)</h6>
                        <h3 class="fw-bold mb-0"><?php echo number_format($total_monthly_amount, 2); ?></h3>
                    </div>
                    <i class="fa-solid fa-money-bill-wave fa-2x opacity-50"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- የትዕዛዞች ሰንጠረዥ -->
    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>ቀን</th>
                            <th>የደንበኛ ስም / ስልክ</th>
                            <th>ከተማ / አካባቢ</th>
                            <th>የእቃው ስም (Product)</th>
                            <th>Pickup Code</th>
                            <th>Transaction ID</th>
                            <th>ክፍያ</th>
                            <th>Status</th>
                            <th style="min-width: 260px;">Status እና መልእክት ማዘመኛ</th>
                            <th>ተግባራት</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($orders_data)): ?>
                            <?php foreach ($orders_data as $ord): 
                                $raw_product_name = $ord['product_name'] ?? 'ያልታወቀ እቃ';
                                $curr_status = $ord['status'] ?? 'Pending';

                                $city = $ord['city'] ?? '';
                                $area = $ord['area'] ?? '';

                                $clean_product_name = trim(preg_replace('/\[የማድረሻ ቦታ:.*?\]/su', '', $raw_product_name));

                                if (preg_match('/\[የማድረሻ ቦታ:-\s*([\s\S]*?)\s*-\s*([\s\S]*?)\]/u', $raw_product_name, $matches)) {
                                    if (empty($city) || $city === 'N/A') {
                                        $city = trim($matches[1]);
                                    }
                                    if (empty($area) || $area === 'N/A') {
                                        $area = trim($matches[2]);
                                    }
                                }

                                if (empty($city)) $city = 'N/A';
                                if (empty($area)) $area = 'N/A';
                            ?>
                                <tr>
                                    <td>#<?php echo htmlspecialchars($ord['id']); ?></td>
                                    <td class="small text-muted">
                                        <?php echo isset($ord['created_at']) ? date('M d, Y', strtotime($ord['created_at'])) : 'N/A'; ?>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars(($ord['first_name'] ?? '') . ' ' . ($ord['last_name'] ?? '')); ?></strong><br>
                                        <small class="text-muted"><?php echo htmlspecialchars($ord['phone'] ?? ''); ?></small>
                                    </td>
                                    
                                    <td class="text-nowrap">
                                        <i class="fa-solid fa-location-dot text-danger me-1"></i>
                                        <strong><?php echo htmlspecialchars($city); ?></strong>, 
                                        <span class="text-muted"><?php echo htmlspecialchars($area); ?></span>
                                    </td>

                                    <td>
                                        <span class="fw-bold text-dark">
                                            <i class="fa-solid fa-box text-secondary me-1"></i>
                                            <?php echo htmlspecialchars($clean_product_name); ?>
                                        </span>
                                    </td>

                                    <td>
                                        <span class="badge bg-dark fs-6 font-monospace px-3 py-2">
                                            <i class="fa-solid fa-key text-warning me-1"></i>
                                            <?php echo htmlspecialchars($ord['pickup_code'] ?? 'N/A'); ?>
                                        </span>
                                    </td>

                                    <td>
                                        <code class="fw-bold text-primary fs-6"><?php echo htmlspecialchars($ord['tx_ref'] ?? 'N/A'); ?></code>
                                    </td>
                                    <td class="fw-bold text-success"><?php echo number_format($ord['amount'] ?? 0, 2); ?> ETB</td>
                                    <td>
                                        <?php if (strcasecmp($curr_status, 'Completed') == 0 || strcasecmp($curr_status, 'Paid') == 0): ?>
                                            <span class="badge bg-success">Success / Paid</span>
                                        <?php elseif (in_array(strtolower($curr_status), ['failed', 'rejected', 'cancelled'])): ?>
                                            <span class="badge bg-danger">Failed / Rejected</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark"><?php echo htmlspecialchars($curr_status); ?></span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <form action="" method="POST" class="d-flex flex-column gap-2 py-1">
                                            <input type="hidden" name="order_id" value="<?php echo $ord['id']; ?>">
                                            
                                            <div class="d-flex gap-1">
                                                <select name="status" class="form-select form-select-sm">
                                                    <option value="Pending" <?php echo (strcasecmp($curr_status, 'Pending') == 0) ? 'selected' : ''; ?>>Pending</option>
                                                    <option value="Paid" <?php echo (strcasecmp($curr_status, 'Paid') == 0) ? 'selected' : ''; ?>>Approved (Paid)</option>
                                                    <option value="Failed" <?php echo (in_array(strtolower($curr_status), ['failed', 'rejected'])) ? 'selected' : ''; ?>>Failed (Reject)</option>
                                                    <option value="Completed" <?php echo (strcasecmp($curr_status, 'Completed') == 0) ? 'selected' : ''; ?>>Completed</option>
                                                </select>
                                                <button type="submit" name="update_status" class="btn btn-sm btn-primary" title="አዘምን">
                                                    <i class="fa-solid fa-check"></i>
                                                </button>
                                            </div>

                                            <input type="text" name="admin_message" class="form-control form-control-sm" 
                                                   placeholder="ለደንበኛው መልእክት..." 
                                                   value="<?php echo htmlspecialchars($ord['admin_message'] ?? ''); ?>">
                                        </form>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-1">
                                            <!-- ደረሰኝ Print -->
                                            <a href="../invoice.php?order_id=<?php echo $ord['id']; ?>" target="_blank" class="btn btn-sm btn-outline-danger" title="ደረሰኝ Print ያድርጉ">
                                                <i class="fa-solid fa-file-pdf"></i>
                                            </a>
                                            <!-- ማጥፊያ (Delete) -->
                                            <form action="" method="POST" onsubmit="return confirm('እርግጠኛ ነዎት ይህን ትዕዛዝ ማጥፋት ይፈልጋሉ?');">
                                                <input type="hidden" name="order_id" value="<?php echo $ord['id']; ?>">
                                                <button type="submit" name="delete_order" class="btn btn-sm btn-outline-dark" title="ሰርዝ">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="11" class="text-center py-4 text-muted">ምንም የቀረበ ትዕዛዝ አልተገኘም።</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>