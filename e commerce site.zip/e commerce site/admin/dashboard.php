<?php include 'header.php'; ?>

<?php
// 1. መረጃዎችን ከዳታቤዝ ማውጣት
$total_products = $conn->query("SELECT COUNT(*) AS count FROM products")->fetch_assoc()['count'] ?? 0;
$total_orders   = $conn->query("SELECT COUNT(*) AS count FROM orders")->fetch_assoc()['count'] ?? 0;
$total_users    = $conn->query("SELECT COUNT(*) AS count FROM users WHERE role='customer'")->fetch_assoc()['count'] ?? 0;
$total_sales    = $conn->query("SELECT SUM(amount) AS total FROM orders")->fetch_assoc()['total'] ?? 0;

// 2. Stock ያለቀባቸው ወይም ከ 5 በታች የሆኑ እቃዎችን መቆጣጠሪያ
$low_stock_limit = 5;
$low_stock_query = $conn->query("SELECT COUNT(*) AS count FROM products WHERE stock <= $low_stock_limit");
$low_stock_count = $low_stock_query ? ($low_stock_query->fetch_assoc()['count'] ?? 0) : 0;
?>

<h3 class="fw-bold mb-4">የአጠቃላይ መረጃዎች ማጠቃለያ</h3>

<!-- STOCK ALERT BANNER (እቃ ሲያልቅ ብቻ የሚታይ) -->
<?php if ($low_stock_count > 0): ?>
    <div class="alert alert-danger border-danger shadow-sm mb-4 p-3 d-flex align-items-center justify-content-between" role="alert">
        <div class="d-flex align-items-center">
            <i class="fa-solid fa-triangle-exclamation fs-3 me-3 text-danger"></i>
            <div>
                <h6 class="fw-bold mb-1 text-danger">የ Stock ማስጠንቀቂያ (Stock Alert)</h6>
                <span class="small text-dark">
                    በአሁኑ ሰዓት <strong><?php echo $low_stock_count; ?></strong> እቃዎች አልቀዋል ወይም መጠናቸው ከ <?php echo $low_stock_limit; ?> በታች ደርሷል!
                </span>
            </div>
        </div>
        <a href="products.php" class="btn btn-sm btn-danger fw-bold shadow-sm">
            <i class="fa-solid fa-boxes-stacked me-1"></i> እቃዎችን አስተካክል
        </a>
    </div>
<?php endif; ?>

<!-- CARDS SUMMARY SECTION -->
<div class="row g-4 mb-5">

    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-white p-3 border-start border-primary border-4">
            <p class="text-muted mb-1 fw-bold">ጠቅላላ ሽያጭ</p>
            <h3 class="fw-bold text-primary"><?php echo number_format($total_sales, 2); ?> ETB</h3>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-white p-3 border-start border-success border-4">
            <p class="text-muted mb-1 fw-bold">የትዕዛዞች ብዛት</p>
            <h3 class="fw-bold text-success"><?php echo $total_orders; ?></h3>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-white p-3 border-start border-warning border-4">
            <p class="text-muted mb-1 fw-bold">የእቃዎች ብዛት</p>
            <h3 class="fw-bold text-warning"><?php echo $total_products; ?></h3>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-white p-3 border-start border-info border-4">
            <p class="text-muted mb-1 fw-bold">ደንበኞች</p>
            <h3 class="fw-bold text-info"><?php echo $total_users; ?></h3>
        </div>
    </div>

    <!-- STOCK NOTIFICATION CARD (በተለየ ካርድ ማሳያ) -->
    <div class="col-md-3">
        <div class="card border-0 shadow-sm bg-white p-3 border-start border-danger border-4">
            <p class="text-muted mb-1 fw-bold">ያለቁ / ያነሱ እቃዎች</p>
            <div class="d-flex align-items-center justify-content-between">
                <h3 class="fw-bold text-danger mb-0"><?php echo $low_stock_count; ?></h3>
                <?php if ($low_stock_count > 0): ?>
                    <span class="badge bg-danger">ማስጠንቀቂያ</span>
                <?php else: ?>
                    <span class="badge bg-success">ደህና</span>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>

</div> <!-- main-content end -->
</div> <!-- row end -->
</div> <!-- container-fluid end -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>