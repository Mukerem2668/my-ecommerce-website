<?php
session_start();
// 1. የ include መስመሩ በ Slash (../) ተስተካክሏል
include '../config/db.php';

$message = "";
$error = "";

// ለማስተካከል የተመረጠውን ምርት ማወቅ
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: admin_products.php");
    exit;
}

$product_id = intval($_GET['id']);

// ምርቱን ማስተካከል (UPDATE)
if (isset($_POST['update_product'])) {
    $name        = trim($_POST['name']);
    $category_id = intval($_POST['category_id']); // Category ID
    $price       = floatval($_POST['price']);
    $description = trim($_POST['description']);
    $image_url   = trim($_POST['image']);

    if (!empty($name) && $price > 0) {
        // Tableህ ላይ category ወይም category_id መሆኑን ማረጋገጥህን አትርሳ
        $stmt = $conn->prepare("UPDATE products SET name = ?, category_id = ?, price = ?, description = ?, image = ? WHERE id = ?");
        $stmt->bind_param("sisssi", $name, $category_id, $price, $description, $image_url, $product_id);
        
        if ($stmt->execute()) {
            $message = "የምርቱ መረጃ በትክክል ተስተካክሏል!";
        } else {
            $error = "ማስተካከል አልተቻለም፦ " . $conn->error;
        }
    } else {
        $error = "እባክዎን ትክክለኛ መረጃ ያስገቡ!";
    }
}

// የነባሩን ምርት መረጃ ከዳታቤዝ ማውጣት
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    header("Location: admin_products.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <title>ምርት አስተካክል - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container my-5" style="max-width: 600px;">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-warning text-dark fw-bold d-flex justify-content-between align-items-center">
            <span><i class="fa-solid fa-pen-to-square me-1"></i> ምርት ማስተካከያ</span>
            <a href="products.php" class="btn btn-sm btn-outline-dark">ተመለስ</a>
        </div>
        <div class="card-body p-4">
            
            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold">የምርት ስም</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($product['name'] ?? ''); ?>" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">ካቴጎሪ (Category ID)</label>
                    <input type="number" name="category_id" class="form-control" value="<?php echo htmlspecialchars($product['category_id'] ?? $product['category'] ?? ''); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">ዋጋ ($ USD)</label>
                    <input type="number" step="0.01" name="price" class="form-control" value="<?php echo htmlspecialchars($product['price'] ?? ''); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">የምስል አድራሻ (Image URL)</label>
                    <input type="text" name="image" class="form-control" value="<?php echo htmlspecialchars($product['image'] ?? ''); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">መግለጫ (Description)</label>
                    <textarea name="description" class="form-control" rows="4"><?php echo htmlspecialchars($product['description'] ?? ''); ?></textarea>
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" name="update_product" class="btn btn-primary w-100 fw-bold">
                        <i class="fa-solid fa-rotate me-1"></i> መረጃውን አዘምን (Update)
                    </button>
                    <a href="products.php" class="btn btn-secondary w-50">ሰርዝ</a>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>