<?php include 'header.php'; ?>

<?php
// የአሁኑን ዓመት መረጃ ማዘጋጀት
$current_year = date('Y');
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : $current_year;

// የወርሃዊ ሽያጭ መረጃዎችን ማዘጋጀት
$sales_monthly = array_fill(1, 12, 0);

$sales_sql = "SELECT MONTH(created_at) AS month_num, SUM(amount) AS monthly_total 
              FROM orders 
              WHERE YEAR(created_at) = '$selected_year' 
              GROUP BY MONTH(created_at)";

$sales_result = $conn->query($sales_sql);

if ($sales_result && $sales_result->num_rows > 0) {
    while ($row = $sales_result->fetch_assoc()) {
        $m = intval($row['month_num']);
        $sales_monthly[$m] = floatval($row['monthly_total']);
    }
}

$chart_data = json_encode(array_values($sales_monthly));

// የአመቱ አጠቃላይ ሽያጭና የትዕዛዝ ብዛት ማጠቃለያ
$summary_sql = "SELECT SUM(amount) AS total_amount, COUNT(*) AS total_orders 
                FROM orders 
                WHERE YEAR(created_at) = '$selected_year'";
$summary_res = $conn->query($summary_sql)->fetch_assoc();
$year_total = $summary_res['total_amount'] ?? 0;
$year_orders = $summary_res['total_orders'] ?? 0;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold mb-0">
        <i class="fa-solid fa-chart-line text-primary me-2"></i>የሽያጭ ትንተና (Sales Analytics)
    </h3>
    
    <!-- የአመት መምረጫ Form -->
    <form method="GET" action="sales-analytics.php" class="d-flex align-items-center gap-2">
        <label class="fw-bold me-1">ዓመት፦</label>
        <select name="year" class="form-select form-select-sm" onchange="this.form.submit()">
            <?php 
            for($y = $current_year; $y >= $current_year - 5; $y--) {
                $sel = ($y == $selected_year) ? 'selected' : '';
                echo "<option value='$y' $sel>$y</option>";
            }
            ?>
        </select>
    </form>
</div>

<!-- የአመቱ አጭር ማጠቃለያ ካርዶች -->
<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm p-3 border-start border-primary border-4">
            <p class="text-muted mb-1 fw-bold">የ <?php echo $selected_year; ?> አጠቃላይ ገቢ</p>
            <h3 class="fw-bold text-primary mb-0"><?php echo number_format($year_total, 2); ?> ETB</h3>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm p-3 border-start border-success border-4">
            <p class="text-muted mb-1 fw-bold">የ <?php echo $selected_year; ?> አጠቃላይ ትዕዛዞች</p>
            <h3 class="fw-bold text-success mb-0"><?php echo $year_orders; ?></h3>
        </div>
    </div>
</div>

<!-- CHART CARD -->
<div class="card border-0 shadow-sm p-4 mb-5">
    <h5 class="fw-bold mb-4 text-dark">የወርሃዊ ሽያጭ ግራፍ (<?php echo $selected_year; ?>)</h5>
    <div style="position: relative; height:380px; width:100%;">
        <canvas id="salesAnalyticsChart"></canvas>
    </div>
</div>

</div> <!-- main-content end -->
</div> <!-- row end -->
</div> <!-- container-fluid end -->

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
const salesData = <?php echo $chart_data; ?>;

const ctx = document.getElementById('salesAnalyticsChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
            label: 'የወሩ ሽያጭ (ETB)',
            data: salesData,
            backgroundColor: 'rgba(13, 110, 253, 0.15)',
            borderColor: '#0d6efd',
            borderWidth: 3,
            fill: true,
            tension: 0.3,
            pointBackgroundColor: '#0d6efd',
            pointRadius: 6,
            pointHoverRadius: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: true, position: 'top' },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return ' ሽያጭ፦ ' + (context.raw || 0).toLocaleString() + ' ETB';
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return value.toLocaleString() + ' ETB';
                    }
                }
            }
        }
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>