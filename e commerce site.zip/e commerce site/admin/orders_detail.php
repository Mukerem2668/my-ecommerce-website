<?php
session_start();
// Admin መሆኑን ማረጋገጫ (አስፈላጊ ከሆነ ክፍት አድርገው)
// if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit(); }

require_once '../config.php'; // ከ admin ፎልደር ውጭ ስላለው config.php

$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($order_id <= 0) {
    header("Location: orders.php");
    exit();
}

// የStatus ማስተካከያ 요청 ከተላከ (Update Status)
if (isset($_POST['update_status'])) {
    $new_status = trim($_POST['status']);
    $update_stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $update_stmt->bind_param("si", $new_status, $order_id);
    if ($update_stmt->execute()) {
        $msg = "የትዕዛዙ ሁኔታ በተሳካ ሁኔታ ተቀይሯል!";
    }
    $update_stmt->close();
}

// የትዕዛዝ መረጃዎችን ከዳታቤዝ ማውጣት
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    die("የትዕዛዝ መረጃው አልተገኘም!");
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>የትዕዛዝ ዝርዝር #<?php echo $order['id']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container my-5" style="max-width: 850px;">
    
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="orders.php" class="btn btn-outline-secondary">
            <i class="fa-solid fa-arrow-left me-1"></i> ወደ ትዕዛዞች ዝርዝር ተመለስ
        </a>
        <a href="../invoice.php?order_id=<?php echo $order['id']; ?>" target="_blank" class="btn btn-primary">
            <i class="fa-solid fa-print me-1"></i> ደረሰኝ (Invoice) አትም
        </a>
    </div>

    <?php if (isset($msg)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-white border-bottom py-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-file-invoice-dollar text-primary me-2"></i>የትዕዛዝ ቁጥር #<?php echo $order['id']; ?></h5>
            <span class="badge <?php echo ($order['status'] == 'Approved' || $order['status'] == 'Completed') ? 'bg-success' : 'bg-warning text-dark'; ?> fs-6">
                <?php echo htmlspecialchars($order['status']); ?>
            </span>
        </div>
        <div class="card-body p-4">
            
            <div class="row g-4 mb-4">
                <!-- የደንበኛ መረጃ -->
                <div class="col-md-6">
                    <div class="p-3 bg-light rounded border h-100">
                        <h6 class="fw-bold text-primary border-bottom pb-2 mb-2"><i class="fa-solid fa-user me-2"></i>የደንበኛ መረጃ</h6>
                        <p class="mb-1"><strong>ስም፦</strong> <?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></p>
                        <p class="mb-1"><strong>ስልክ፦</strong> <?php echo htmlspecialchars($order['phone']); ?></p>
                        <p class="mb-0"><strong>ኢሜይል፦</strong> <?php echo htmlspecialchars($order['email']); ?></p>
                    </div>
                </div>

                <!-- የመረከቢያ አድራሻ -->
                <div class="col-md-6">
                    <div class="p-3 bg-light rounded border h-100">
                        <h6 class="fw-bold text-primary border-bottom pb-2 mb-2"><i class="fa-solid fa-location-dot me-2"></i>የመቀበያ አድራሻ</h6>
                        <p class="mb-1"><strong>ከተማ፦</strong> <?php echo htmlspecialchars($order['city']); ?></p>
                        <p class="mb-1"><strong>ሰፈር፦</strong> <?php echo htmlspecialchars($order['area']); ?></p>
                        <p class="mb-0"><strong>Pickup Code፦</strong> <span class="badge bg-dark font-monospace"><?php echo htmlspecialchars($order['pickup_code']); ?></span></p>
                    </div>
                </div>
            </div>

            <!-- የታዘዙ እቃዎች Table -->
            <h6 class="fw-bold text-dark mb-2"><i class="fa-solid fa-boxes-stacked me-2"></i>የታዘዙ እቃዎች</h6>
            <table class="table table-bordered mb-4 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>የምርት/እቃ ስም</th>
                        <th class="text-end">ጠቅላላ ዋጋ (ETB)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($order['product_name']); ?></strong></td>
                        <td class="text-end fw-bold text-success fs-6"><?php echo number_format($order['amount'], 2); ?> ETB</td>
                    </tr>
                </tbody>
            </table>

            <!-- የክፍያ መረጃ & Transaction ID -->
            <div class="p-3 bg-light rounded border mb-4">
                <div class="row align-items-center">
                    <div class="col-md-7">
                        <p class="mb-1"><strong>Transaction ID፦</strong> <code class="fs-6 text-danger"><?php echo htmlspecialchars($order['tx_ref']); ?></code></p>
                        <p class="mb-0 text-muted small">ቀን፦ <?php echo date('M d, Y - h:i A', strtotime($order['created_at'] ?? 'now')); ?></p>
                    </div>
                    <div class="col-md-5 text-md-end mt-2 mt-md-0">
                        <span class="fs-5 fw-bold text-primary">ድምር፦ <?php echo number_format($order['amount'], 2); ?> ETB</span>
                    </div>
                </div>
            </div>

            <!-- የትዕዛዝ ሁኔታ መቆጣጠሪያ (Update Status Form) -->
            <div class="card border-primary">
                <div class="card-header bg-primary text-white fw-bold">
                    <i class="fa-solid fa-pen-to-square me-2"></i>የትዕዛዝ ሁኔታን ቀይር (Update Status)
                </div>
                <div class="card-body">
                    <form action="" method="POST" class="row g-2 align-items-center">
                        <div class="col-sm-8">
                            <select name="status" class="form-select fw-bold">
                                <option value="Pending" <?php if ($order['status'] == 'Pending') echo 'selected'; ?>>Pending (በመጠበቅ ላይ)</option>
                                <option value="Approved" <?php if ($order['status'] == 'Approved') echo 'selected'; ?>>Approved (ክፍያ ተረጋግጧል)</option>
                                <option value="Completed" <?php if ($order['status'] == 'Completed') echo 'selected'; ?>>Completed (እቃ ተረክቧል)</option>
                                <option value="Cancelled" <?php if ($order['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled (ተሰርዟል)</option>
                            </select>
                        </div>
                        <div class="col-sm-4">
                            <button type="submit" name="update_status" class="btn btn-success w-100 fw-bold">
                                <i class="fa-solid fa-floppy-disk me-1"></i> Save Status
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>