<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../config/db.php';

// Admin መሆኑን ማረጋገጥ
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$logged_admin_id = $_SESSION['user_id'] ?? 0;
$success_msg = "";
$error_msg = "";

// ==========================================
// 1. የራስን ፕሮፋይል እና ፓስወርድ ማዘመኛ
// ==========================================
if (isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];

    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $logged_admin_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($res && password_verify($current_password, $res['password'])) {
        if (!empty($new_password)) {
            $hashed_pass = password_hash($new_password, PASSWORD_BCRYPT);
            $update_stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?");
            $update_stmt->bind_param("sssi", $name, $email, $hashed_pass, $logged_admin_id);
        } else {
            $update_stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
            $update_stmt->bind_param("ssi", $name, $email, $logged_admin_id);
        }

        if ($update_stmt->execute()) {
            $_SESSION['user_name'] = $name;
            $success_msg = "ፕሮፋይልዎ በትክክል ተዘምኗል!";
        } else {
            $error_msg = "ማዘመን አልተቻለም፦ " . $conn->error;
        }
        $update_stmt->close();
    } else {
        $error_msg = "ያሰገቡት የቆየ ፓስወርድ የተሳሳተ ነው!";
    }
}

// ==========================================
// 2. የራስን አካውንት ሙሉ በሙሉ ማጥፋት (Delete Self Account)
// ==========================================
if (isset($_POST['delete_self_account'])) {
    $confirm_password = $_POST['confirm_password_delete'];

    // ፓስወርዱን ማረጋገጥ
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $logged_admin_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($res && password_verify($confirm_password, $res['password'])) {
        $del_stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $del_stmt->bind_param("i", $logged_admin_id);
        if ($del_stmt->execute()) {
            session_destroy();
            header("Location: ../login.php?msg=account_deleted");
            exit;
        } else {
            $error_msg = "አካውንቱን ማጥፋት አልተቻለም፦ " . $conn->error;
        }
        $del_stmt->close();
    } else {
        $error_msg = "አካውንትዎን ለማጥፋት ያሰገቡት ፓስወርድ የተሳሳተ ነው!";
    }
}

// ==========================================
// 3. አዲስ አድሚን መጨመር (Add New Admin)
// ==========================================
if (isset($_POST['add_admin'])) {
    $new_name = trim($_POST['new_name']);
    $new_email = trim($_POST['new_email']);
    $new_pass = $_POST['new_password_add'];
    $role = 'admin';

    $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check_stmt->bind_param("s", $new_email);
    $check_stmt->execute();
    if ($check_stmt->get_result()->num_rows > 0) {
        $error_msg = "ይህ ኢሜይል ቀደም ብሎ ተመዝግቧል!";
    } else {
        $hashed_pass = password_hash($new_pass, PASSWORD_BCRYPT);
        $add_stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $add_stmt->bind_param("ssss", $new_name, $new_email, $hashed_pass, $role);
        if ($add_stmt->execute()) {
            $success_msg = "አዲስ አድሚን በትክክል ተጨምሯል!";
        } else {
            $error_msg = "አድሚን መጨመር አልተቻለም፦ " . $conn->error;
        }
        $add_stmt->close();
    }
    $check_stmt->close();
}

// ==========================================
// 4. ሌላ አድሚን ማጥፋት (Delete Other Admin)
// ==========================================
if (isset($_GET['delete_admin'])) {
    $delete_id = intval($_GET['delete_admin']);

    if ($delete_id == $logged_admin_id) {
        $error_msg = "የራስዎን አካውንት ከዚህ ማጥፋት አይችሉም! ከላይ ያለውን የራስ አካውንት ማጥፊያ ይተቀሙ።";
    } else {
        $del_stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND role = 'admin'");
        $del_stmt->bind_param("i", $delete_id);
        if ($del_stmt->execute()) {
            $success_msg = "አድሚኑ በትክክል ተሰርዟል!";
        }
        $del_stmt->close();
    }
}

// የአሁኑን አድሚን መረጃ ማምጣት
$me_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$me_stmt->bind_param("i", $logged_admin_id);
$me_stmt->execute();
$current_admin = $me_stmt->get_result()->fetch_assoc();
$me_stmt->close();

// ሁሉንም አድሚኖች ዝርዝር ማምጣት
$all_admins = $conn->query("SELECT id, name, email, created_at FROM users WHERE role = 'admin' ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Profile & Account Settings</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold m-0"><i class="fa-solid fa-user-gear me-2"></i> የአድሚን ሴቲንግ (Profile Settings)</h3>
        <a href="dashboard.php" class="btn btn-outline-dark"><i class="fa-solid fa-arrow-left me-1"></i> ወደ Dashboard</a>
    </div>

    <!-- መልእክት ማሳያ -->
    <?php if (!empty($success_msg)): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm">
            <i class="fa-solid fa-circle-check me-2"></i><?php echo htmlspecialchars($success_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_msg)): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm">
            <i class="fa-solid fa-circle-exclamation me-2"></i><?php echo htmlspecialchars($error_msg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- 1. የራሴን ፕሮፋይል መቀየሪያ እና አካውንት ማጥፊያ -->
        <div class="col-md-6">
            <div class="card shadow-sm border-0 p-4">
                <h5 class="fw-bold mb-3"><i class="fa-solid fa-pen-to-square me-2 text-primary"></i>የኔን መረጃ/ፓስወርድ ቀይር</h5>
                <form action="" method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">ስም</label>
                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($current_admin['name'] ?? ''); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">ኢሜይል</label>
                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($current_admin['email'] ?? ''); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-danger">አሁን ያለህ ፓስወርድ (ለማረጋገጫ)</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-success">አዲስ ፓስወርድ (መቀየር ካልፈለግክ ባዶ ይሁኑ)</label>
                        <input type="password" name="new_password" class="form-control" placeholder="አዲስ ፓስወርድ...">
                    </div>
                    <button type="submit" name="update_profile" class="btn btn-primary w-100 fw-bold mb-3">
                        <i class="fa-solid fa-floppy-disk me-1"></i> መረጃውን አዘምን
                    </button>
                </form>

                <hr>

                <!-- የራስን አካውንት ማጥፊያ Button -->
                <div class="d-flex justify-content-between align-items-center">
                    <span class="small text-danger fw-bold">አካውንትዎን ማጥፋት ይፈልጋሉ?</span>
                    <button type="button" class="btn btn-outline-danger btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#deleteSelfModal">
                        <i class="fa-solid fa-user-xmark me-1"></i> አካውንቴን ሰርዝ
                    </button>
                </div>
            </div>
        </div>

        <!-- 2. አዲስ አድሚን መጨመሪያ -->
        <div class="col-md-6">
            <div class="card shadow-sm border-0 p-4">
                <h5 class="fw-bold mb-3"><i class="fa-solid fa-user-plus me-2 text-success"></i>አዲስ አድሚን ጨምር</h5>
                <form action="" method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">የአድሚኑ ስም</label>
                        <input type="text" name="new_name" class="form-control" placeholder="ምሳሌ፦ አበበ ከበደ" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">ኢሜይል</label>
                        <input type="email" name="new_email" class="form-control" placeholder="admin@example.com" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">የይለፍ ቃል (Password)</label>
                        <input type="password" name="new_password_add" class="form-control" required>
                    </div>
                    <button type="submit" name="add_admin" class="btn btn-success w-100 fw-bold">
                        <i class="fa-solid fa-plus me-1"></i> አድሚኑን ይመዝግቡ
                    </button>
                </form>
            </div>
        </div>

        <!-- 3. ሁሉንም አድሚኖች ዝርዝር ማሳያ -->
        <div class="col-12">
            <div class="card shadow-sm border-0 p-4">
                <h5 class="fw-bold mb-3"><i class="fa-solid fa-users me-2 text-dark"></i>የአድሚኖች ዝርዝር</h5>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>#ID</th>
                                <th>ስም</th>
                                <th>ኢሜይል</th>
                                <th>የተመዘገበበት ቀን</th>
                                <th>ተግባር (Action)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($all_admins && $all_admins->num_rows > 0): ?>
                                <?php while ($adm = $all_admins->fetch_assoc()): ?>
                                    <tr>
                                        <td>#<?php echo $adm['id']; ?></td>
                                        <td><strong><?php echo htmlspecialchars($adm['name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($adm['email']); ?></td>
                                        <td class="small text-muted"><?php echo date('M d, Y', strtotime($adm['created_at'] ?? 'now')); ?></td>
                                        <td>
                                            <?php if ($adm['id'] == $logged_admin_id): ?>
                                                <span class="badge bg-primary">የእርስዎ አካውንት</span>
                                            <?php else: ?>
                                                <a href="?delete_admin=<?php echo $adm['id']; ?>" 
                                                   class="btn btn-sm btn-outline-danger" 
                                                   onclick="return confirm('እርግጠኛ ነዎት ይህንን አድሚን ማሰናበት ይፈልጋሉ?');">
                                                    <i class="fa-solid fa-trash me-1"></i> ሰርዝ
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- አካውንት ማጥፊያ ማረጋገጫ Popup (Modal) -->
<div class="modal fade" id="deleteSelfModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-triangle-exclamation me-2"></i>አካውንት ማጥፋት</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body text-center p-4">
                    <p class="text-dark fw-bold mb-2">እርግጠኛ ነዎት አካውንትዎን ማጥፋት ይፈልጋሉ?</p>
                    <p class="small text-muted mb-3">ይህ ተግባር በድጋሚ አይመለስም። ለማረጋገጥ እባክዎ አሁን ያለዎትን ፓስወርድ ያስገቡ።</p>
                    <input type="password" name="confirm_password_delete" class="form-control text-center" placeholder="የአሁኑን ፓስወርድ ያስገቡ" required>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ሰርዝ</button>
                    <button type="submit" name="delete_self_account" class="btn btn-danger fw-bold">አካውንቴን በቋሚነት አጥፋ</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>