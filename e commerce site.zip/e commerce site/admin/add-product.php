<?php 
include 'header.php'; 

$message = '';

if (isset($_POST['add_product'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $category_id = $conn->real_escape_string($_POST['category_id']);
    $price = floatval($_POST['price']);
    $description = $conn->real_escape_string($_POST['description']);

    // Image Upload Handling
    $image_name = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $image_ext = pathinfo($image_name, PATHINFO_EXTENSION);
    $new_image_name = time() . '_' . uniqid() . '.' . $image_ext;
    $upload_dir = "../uploads/" . $new_image_name;
    $db_image_path = "uploads/" . $new_image_name;

    if (move_uploaded_file($image_tmp, $upload_dir)) {
        $sql = "INSERT INTO products (category_id, name, description, price, image) 
                VALUES ('$category_id', '$name', '$description', '$price', '$db_image_path')";
        if ($conn->query($sql)) {
            $message = '<div class="alert alert-success">እቃው በተሳካ ሁኔታ ተጨምሯል!</div>';
        } else {
            $message = '<div class="alert alert-danger">Database ስህተት፡ ' . $conn->error . '</div>';
        }
    } else {
        $message = '<div class="alert alert-danger">ፎቶውን መጫን አልተቻለም! እባክዎን የ uploads/ ፎልደር መኖሩን ያረጋግጡ።</div>';
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h4 class="fw-bold mb-4">አዲስ እቃ መጨመሪያ</h4>
                <?php echo $message; ?>

                <form action="add-product.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label fw-bold">የእቃው ስም</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
  
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">ምድብ (Category)</label>
                            <select name="category_id" class="form-select" required>
                                <option value="">ምድብ ይምረጡ</option>
                                <option value="Electronics">Electronics</option>
                                <option value="Fashion">Fashion</option>
                                <option value="Food">Food</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">ዋጋ ($)</label>
                            <input type="number" step="0.01" name="price" class="form-control" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">የእቃው ፎቶ</label>
                        <input type="file" name="image" class="form-control" accept="image/*" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold">መግለጫ (Description)</label>
                        <textarea name="description" class="form-control" rows="4" required></textarea>
                    </div>

                    <button type="submit" name="add_product" class="btn btn-primary px-4"><i class="fa-solid fa-plus me-1"></i> እቃውን መዝግብ</button>
                    <a href="products.php" class="btn btn-outline-secondary px-4">ተመለስ</a>
                </form>
            </div>
        </div>
    </div>
</div>

</div></div></div></body></html>