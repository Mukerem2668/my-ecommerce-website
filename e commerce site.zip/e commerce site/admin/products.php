<?php 
include 'header.php'; 

// Stock update logic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_stock'])) {
    $product_id = intval($_POST['product_id']);
    $new_stock = intval($_POST['stock']);

    $stmt = $conn->prepare("UPDATE products SET stock = ? WHERE id = ?");
    $stmt->bind_param("ii", $new_stock, $product_id);
    if ($stmt->execute()) {
        $stock_msg = '<div class="alert alert-success alert-dismissible fade show" role="alert">
                        የእቃው ስቶክ መጠን በትክክል ተስተካክሏል!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
    } else {
        $stock_msg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        ስቶክ ማስተካከል አልተቻለም፡ ' . $conn->error . '
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                      </div>';
    }
    $stmt->close();
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold m-0">የእቃዎች እና የStock ዝርዝር</h3>
    <a href="add-product.php" class="btn btn-primary"><i class="fa-solid fa-plus me-1"></i> አዲስ እቃ ጨምር</a>
</div>

<?php if (isset($stock_msg)) echo $stock_msg; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>ፎቶ</th>
                        <th>ስም</th>
                        <th>ምድብ</th>
                        <th>ዋጋ</th>
                        <th>Stock መጠን</th>
                        <th>ሁኔታ (Status)</th>
                        <th>ተግባር (Action)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT p.*, c.category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC";
                    $result = $conn->query($sql);

                    if ($result && $result->num_rows > 0):
                        while ($row = $result->fetch_assoc()):
                            $stock = isset($row['stock']) ? intval($row['stock']) : 0;
                            
                            // Stock status logic
                            if ($stock <= 0) {
                                $status_badge = '<span class="badge bg-danger">Out of Stock</span>';
                            } elseif ($stock < 5) {
                                $status_badge = '<span class="badge bg-warning text-dark">Low Stock (' . $stock . ')</span>';
                            } else {
                                $status_badge = '<span class="badge bg-success">In Stock (' . $stock . ')</span>';
                            }
                    ?>
                        <tr>
                            <td>#<?php echo $row['id']; ?></td>
                            <td>
                                <img src="../<?php echo htmlspecialchars($row['image']); ?>" style="width: 50px; height: 50px; object-fit: cover;" class="rounded" onerror="this.src='https://via.placeholder.com/50';">
                            </td>
                            <td class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><span class="badge bg-secondary"><?php echo htmlspecialchars($row['category_name'] ?? 'Uncategorized'); ?></span></td>
                            <td class="text-primary fw-bold">$<?php echo number_format($row['price'], 2); ?></td>
                            
                            <!-- Stock Quantity and Quick Update Form -->
                            <td>
                                <form action="" method="POST" class="d-flex align-items-center gap-1" style="max-width: 130px;">
                                    <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                    <input type="number" name="stock" class="form-control form-control-sm text-center" value="<?php echo $stock; ?>" min="0" required>
                                    <button type="submit" name="update_stock" class="btn btn-sm btn-outline-success" title="Stock አድስ">
                                        <i class="fa-solid fa-check"></i>
                                    </button>
                                </form>
                            </td>

                            <td><?php echo $status_badge; ?></td>

                            <td>
                                <a href="edit-product.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-primary me-1" title="አስተካክል"><i class="fa-solid fa-pen"></i></a>
                                <a href="delete-product.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('እርግጠኛ ነዎት ይህ እቃ ይጥፋ?')" title="ሰርዝ"><i class="fa-solid fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php 
                        endwhile;
                    else:
                    ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">ምንም የተመዘገበ እቃ የለም።</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div></div></div></body></html>