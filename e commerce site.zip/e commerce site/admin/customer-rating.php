<?php
include '../config/db.php';

// አስተያየት ለመሰረዝ (Delete)
if (isset($_GET['delete'])) {
    $review_id = intval($_GET['delete']);
    $stmt_del = $conn->prepare("DELETE FROM reviews WHERE id = ?");
    $stmt_del->bind_param("i", $review_id);
    if ($stmt_del->execute()) {
        echo "<script>alert('አስተያየቱ በስኬት ተሰርዟል!'); window.location.href='reviews.php';</script>";
    }
    $stmt_del->close();
}

// ሁሉንም አስተያየቶች ከምርቱ ስም ጋር አጣጥፎ ማውጣት
$sql = "SELECT r.*, p.name AS product_name 
        FROM reviews r 
        LEFT JOIN products p ON r.product_id = p.id 
        ORDER BY r.id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>የደንበኞች አስተያየት - Admin</title>
    <!-- Bootstrap CSS & FontAwesome -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<!-- Custom Admin Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold text-primary" href="dashboard.php">
            <i class="fa-solid fa-shield-halved me-2"></i>Admin Dashboard
        </a>
        <div class="ms-auto">
            <a href="dashboard.php" class="btn btn-outline-light btn-sm fw-bold">
                <i class="fa-solid fa-arrow-left me-1"></i> ወደ Dashboard ተመለስ
            </a>
        </div>
    </div>
</nav>

<!-- Main Content -->
<div class="container-fluid px-4 my-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0"><i class="fa-solid fa-comments me-2 text-primary"></i>የደንበኞች አስተያየቶች እና Rating</h3>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th class="ps-3">#</th>
                            <th>የምርቱ ስም</th>
                            <th>የደንበኛው ስም</th>
                            <th>Rating</th>
                            <th>አስተያየት (Comment)</th>
                            <th>ቀን</th>
                            <th class="text-center">ድርጊት (Action)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php $count = 1; while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-3 fw-bold"><?php echo $count++; ?></td>
                                    <td class="fw-bold text-dark"><?php echo htmlspecialchars($row['product_name'] ?? 'የተሰረዘ እቃ'); ?></td>
                                    <td><?php echo htmlspecialchars($row['user_name'] ?? 'Guest'); ?></td>
                                    <td>
                                        <span class="text-warning fw-bold">
                                            <?php 
                                            $rating = intval($row['rating']);
                                            for ($i = 1; $i <= 5; $i++) {
                                                echo ($i <= $rating) ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star text-muted"></i>';
                                            }
                                            ?>
                                        </span>
                                        <small class="text-muted fw-bold">(<?php echo $rating; ?>/5)</small>
                                    </td>
                                    <td><?php echo nl2br(htmlspecialchars($row['comment'] ?? '')); ?></td>
                                    <td><small class="text-muted"><?php echo date('M d, Y - H:i', strtotime($row['created_at'])); ?></small></td>
                                    <td class="text-center">
                                        <a href="reviews.php?delete=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-outline-danger px-3" 
                                           onclick="return confirm('እርግጠኛ ነዎት ይህን አስተያየት መሰረዝ ይፈልጋሉ?');">
                                            <i class="fa-solid fa-trash me-1"></i> ሰርዝ
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-5">
                                    <i class="fa-solid fa-comment-slash fa-2x mb-2 d-block"></i>
                                    እስካሁን ምንም አይነት አስተያየት አልተሰጠም።
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>