<?php
session_start();
require_once '../config/db.php'; // ከ admin ፎልደር ውጭ ስላለው config/db.php

$msg = '';
$error = '';

// Edit ለማድረግ መረጃዎችን ማዘጋጀት
$edit_mode = false;
$edit_id = 0;
$edit_name = '';
$edit_price = '';
$edit_category = '';
$edit_stock = 10;
$edit_description = '';
$edit_image = '';

if (isset($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $edit_mode = true;
        $row = $res->fetch_assoc();
        $edit_name = $row['name'];
        $edit_price = $row['price'];
        $edit_category = $row['category'];
        $edit_stock = $row['stock'];
        $edit_description = $row['description'];
        $edit_image = $row['image'];
    }
    $stmt->close();
}

// 1. አዲስ እቃ መጨመር ወይም ማስተካከል (Add / Update Product)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_product'])) {
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $name = trim($_POST['name']);
    $price = floatval($_POST['price']);
    $category = trim($_POST['category']);
    $stock = intval($_POST['stock']);
    $description = trim($_POST['description']);
    $old_image = $_POST['old_image'] ?? '';

    // የምስል/Image መስቀያ (Upload)
    $image_name = $old_image; // በነባሪ የቀደመውን ምስል መያዝ
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($file_ext, $allowed_ext)) {
            $image_name = time() . '_' . uniqid() . '.' . $file_ext;
            $upload_path = '../uploads/' . $image_name;
            
            if (!is_dir('../uploads')) {
                mkdir('../uploads', 0777, true);
            }
            if (move_uploaded_file($file_tmp, $upload_path)) {
                // አዲስ ምስል ከተጫነ የቀደመውን ማጥፋት
                if (!empty($old_image) && file_exists('../uploads/' . $old_image)) {
                    unlink('../uploads/' . $old_image);
                }
            }
        } else {
            $error = "እባክዎን ትክክለኛ የምስል አይነት (JPG, PNG, WEBP) ያስገቡ!";
        }
    }

    if (empty($error)) {
        if ($product_id > 0) {
            // Update Existing Product
            $stmt = $conn->prepare("UPDATE products SET name=?, price=?, category=?, stock=?, description=?, image=? WHERE id=?");
            $stmt->bind_param("sdsissi", $name, $price, $category, $stock, $description, $image_name, $product_id);
            if ($stmt->execute()) {
                $msg = "የእቃው መረጃ በትክክል ተስተካክሏል!";
            } else {
                $error = "መረጃውን ማስተካከል አልተቻለም።";
            }
            $stmt->close();
        } else {
            // Insert New Product
            $stmt = $conn->prepare("INSERT INTO products (name, price, category, stock, description, image) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sdsiss", $name, $price, $category, $stock, $description, $image_name);
            if ($stmt->execute()) {
                $msg = "እቃው በትክክል ተጨምሯል!";
            } else {
                $error = "እቃውን መጨመር አልተቻለም።";
            }
            $stmt->close();
        }
    }
}

// 2. እቃ መሰረዝ (Delete Product)
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    
    $img_stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
    $img_stmt->bind_param("i", $delete_id);
    $img_stmt->execute();
    $img_res = $img_stmt->get_result()->fetch_assoc();
    if (!empty($img_res['image']) && file_exists('../uploads/' . $img_res['image'])) {
        unlink('../uploads/' . $img_res['image']);
    }
    $img_stmt->close();

    $del_stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $del_stmt->bind_param("i", $delete_id);
    if ($del_stmt->execute()) {
        $msg = "እቃው ተሰርዟል!";
    }
    $del_stmt->close();
    header("Location: products.php");
    exit();
}

// 3. ፍለጋ (Search Filter) እና እቃዎችን ከዳታቤዝ ማውጣት
$search = trim($_GET['search'] ?? '');
if (!empty($search)) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? OR category LIKE ? ORDER BY id DESC");
    $search_param = "%" . $search . "%";
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM products ORDER BY id DESC");
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>እቃዎች ማስተዳደሪያ - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container py-5">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold text-primary"><i class="fa-solid fa-boxes-packing me-2"></i>የእቃዎች ማስተዳደሪያ (Products)</h3>
        <a href="orders.php" class="btn btn-outline-secondary"><i class="fa-solid fa-list-check me-1"></i> ወደ ትዕዛዞች ገፅ</a>
    </div>

    <!-- Alert Notifications -->
    <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show"><?php echo $msg; ?><button class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?php echo $error; ?><button class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <div class="row g-4">
        
        <!-- እቃ መጨመሪያ / ማስተካከያ Form -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-header <?php echo $edit_mode ? 'bg-warning text-dark' : 'bg-primary text-white'; ?> py-3 fw-bold d-flex justify-content-between align-items-center">
                    <span>
                        <i class="fa-solid <?php echo $edit_mode ? 'fa-pen-to-square' : 'fa-plus-circle'; ?> me-1"></i> 
                        <?php echo $edit_mode ? 'እቃ አስተካክል' : 'አዲስ እቃ ጨምር'; ?>
                    </span>
                    <?php if ($edit_mode): ?>
                        <a href="products.php" class="btn btn-sm btn-outline-dark">ሰርዝ</a>
                    <?php endif; ?>
                </div>
                <div class="card-body p-4">
                    <form action="products.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="product_id" value="<?php echo $edit_id; ?>">
                        <input type="hidden" name="old_image" value="<?php echo htmlspecialchars($edit_image); ?>">

                        <div class="mb-3">
                            <label class="form-label fw-semibold small">የእቃ ስም</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($edit_name); ?>" placeholder="ምሳሌ: Samsung Ultra S24" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">ዋጋ (ETB)</label>
                            <input type="number" step="0.01" name="price" class="form-control" value="<?php echo htmlspecialchars($edit_price); ?>" placeholder="80000" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">ካቴጎሪ (Category)</label>
                            <input type="text" name="category" class="form-control" value="<?php echo htmlspecialchars($edit_category); ?>" placeholder="ምሳሌ: Electronics" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">ብዛት (Stock Quantity)</label>
                            <input type="number" name="stock" class="form-control" value="<?php echo htmlspecialchars($edit_stock); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">ምስል (Image)</label>
                            <input type="file" name="image" class="form-control" accept="image/*" <?php echo $edit_mode ? '' : 'required'; ?>>
                            <?php if ($edit_mode && !empty($edit_image)): ?>
                                <div class="mt-2">
                                    <small class="text-muted">የአሁኑ ምስል:</small><br>
                                    <img src="../uploads/<?php echo htmlspecialchars($edit_image); ?>" class="rounded mt-1" style="width: 50px; height: 50px; object-fit: cover;">
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">የእቃው ዝርዝር መግለጫ</label>
                            <textarea name="description" class="form-control" rows="3" placeholder="ስለ እቃው ማብራሪያ..."><?php echo htmlspecialchars($edit_description); ?></textarea>
                        </div>
                        <button type="submit" name="save_product" class="btn <?php echo $edit_mode ? 'btn-warning' : 'btn-primary'; ?> w-100 fw-bold">
                            <i class="fa-solid fa-save me-1"></i> <?php echo $edit_mode ? 'መረጃዉን አሻሽል' : 'እቃውን መዝግብ'; ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- የእቃዎች ዝርዝር Table -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <h5 class="fw-bold mb-0 text-dark">የሁሉም እቃዎች ዝርዝር</h5>
                    
                    <!-- Search Form -->
                    <form action="products.php" method="GET" class="d-flex gap-2" style="max-width: 300px;">
                        <input type="text" name="search" class="form-control form-control-sm" placeholder="በስም ወይም በካቴጎሪ ፈልግ..." value="<?php echo htmlspecialchars($search); ?>">
                        <button type="submit" class="btn btn-sm btn-primary"><i class="fa-solid fa-magnifying-glass"></i></button>
                        <?php if (!empty($search)): ?>
                            <a href="products.php" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-xmark"></i></a>
                        <?php endif; ?>
                    </form>

                    <span class="badge bg-secondary"><?php echo $result ? $result->num_rows : 0; ?> እቃዎች</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>ምስል</th>
                                    <th>ስም</th>
                                    <th>ካቴጎሪ</th>
                                    <th>ዋጋ</th>
                                    <th>Stock</th>
                                    <th class="text-center">ድርጊት</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result && $result->num_rows > 0): ?>
                                    <?php while ($product = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <img src="../uploads/<?php echo htmlspecialchars($product['image']); ?>" class="rounded" style="width: 45px; height: 45px; object-fit: cover;" onerror="this.src='https://via.placeholder.com/45';">
                                            </td>
                                            <td class="fw-bold text-dark"><?php echo htmlspecialchars($product['name']); ?></td>
                                            <td><span class="badge bg-light text-dark border"><?php echo htmlspecialchars($product['category']); ?></span></td>
                                            <td class="fw-semibold text-success"><?php echo number_format($product['price'], 2); ?> ETB</td>
                                            <td><span class="badge bg-info-subtle text-info fw-bold"><?php echo $product['stock']; ?></span></td>
                                            <td class="text-center">
                                                <a href="products.php?edit=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-primary me-1" title="አስተካክል">
                                                    <i class="fa-solid fa-pen"></i>
                                                </a>
                                                <a href="products.php?delete=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('እርግጠኛ ነዎት ይህ እቃ እንዲሰረዝ ይፈልጋሉ?');" title="ሰርዝ">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4 text-muted">ምንም የተመዘገበ እቃ የለም።</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>