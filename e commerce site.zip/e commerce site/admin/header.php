<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../config/db.php';

// Admin መሆኑን ማረጋገጥ
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// ያለንበትን ገፅ አድራሻ ማወቅ (ለ Sidebar Active Link)
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MUKKA SHOP - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f9fa; }
        .sidebar { min-height: 100vh; background-color: #212529; color: #fff; display: flex; flex-direction: column; }
        .sidebar a { color: #adb5bd; text-decoration: none; padding: 12px 20px; display: block; border-radius: 5px; margin-bottom: 5px; }
        .sidebar a:hover, .sidebar a.active { background-color: #0d6efd; color: #fff; }
        .main-content { padding: 30px; }

        /* የ Google Translate Top Banner እና iframe መደበቂያ */
        .goog-te-banner-frame, .skiptranslate, iframe.skiptranslate {
            display: none !important;
        }
        body {
            top: 0px !important;
        }
        .goog-te-gadget-icon {
            display: none !important;
        }

        /* FontAwesome አዶዎች እንዳይበላሹ ማድረግ */
        .fa, .fas, .far, .fal, .fab, .fa-solid, .fa-regular {
            font-family: "Font Awesome 6 Free", "Font Awesome 6 Brands" !important;
        }

        @media (max-width: 767.98px) {
            .main-content { padding: 15px; }
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <!-- Desktop Sidebar Navigation -->
        <div class="col-md-3 col-lg-2 sidebar p-3 d-none d-md-flex">
            <h4 class="text-center text-primary fw-bold my-3">MUKKA <span class="text-white">ADMIN</span></h4>
            <hr class="text-secondary">
            
            <nav class="mt-2 flex-grow-1">
                <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-gauge me-2"></i><span>Dashboard</span>
                </a>
                <a href="products.php" class="<?php echo ($current_page == 'products.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-box me-2"></i><span>Products</span>
                </a>
                <a href="add-product.php" class="<?php echo ($current_page == 'add-product.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-plus me-2"></i><span>Add Product</span>
                </a>
                <a href="order.php" class="<?php echo ($current_page == 'order.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-cart-shopping me-2"></i><span>Orders</span>
                </a>
                <a href="customer-rating.php" class="<?php echo ($current_page == 'customer-rating.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-star me-2"></i><span>Customer Ratings</span>
                </a>
                <a href="sales-analytics.php" class="<?php echo ($current_page == 'sales-analytics.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-chart-line me-2 text-warning"></i><span>Sales Analytics</span>
                </a>
                <a href="profile.php" class="<?php echo ($current_page == 'profile.php') ? 'active' : ''; ?>">
                    <i class="fa-solid fa-user-gear me-2"></i><span>Settings</span>
                </a>
                
                
           </nav>

            <div class="pt-3 border-top border-secondary">
                <a href="../logout.php" class="btn btn-danger w-100 text-white fw-bold">
                    <i class="fa-solid fa-right-from-bracket me-2"></i><span>Logout</span>
                </a>
            </div>
        </div>

        <!-- Mobile Offcanvas Sidebar Navigation -->
        <div class="offcanvas offcanvas-start bg-dark text-white d-md-none" tabindex="-1" id="mobileSidebar" aria-labelledby="mobileSidebarLabel">
            <div class="offcanvas-header border-bottom border-secondary">
                <h5 class="offcanvas-title text-primary fw-bold" id="mobileSidebarLabel">MUKKA <span class="text-white">ADMIN</span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body sidebar p-3">
                <nav class="mt-2 flex-grow-1">
                    <a href="dashboard.php" class="<?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-gauge me-2"></i><span>Dashboard</span>
                    </a>
                    <a href="products.php" class="<?php echo ($current_page == 'products.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-box me-2"></i><span>Products</span>
                    </a>
                    <a href="add-product.php" class="<?php echo ($current_page == 'add-product.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-plus me-2"></i><span>Add Product</span>
                    </a>
                    <a href="order.php" class="<?php echo ($current_page == 'order.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-cart-shopping me-2"></i><span>Orders</span>
                    </a>
                    <a href="customer-rating.php" class="<?php echo ($current_page == 'customer-rating.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-star me-2"></i><span>Customer Ratings</span>
                    </a>
                    <a href="sales-analytics.php" class="<?php echo ($current_page == 'sales-analytics.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-chart-line me-2 text-warning"></i><span>Sales Analytics</span>
                    </a>
                    <a href="profile.php" class="<?php echo ($current_page == 'profile.php') ? 'active' : ''; ?>">
                        <i class="fa-solid fa-user-gear me-2"></i><span>Settings</span>
                    </a>
                    
                    <a href="../index.php" target="_blank" class="text-info fw-bold mt-2">
                        <i class="fa-solid fa-globe me-2"></i><span>View Site</span>
                    </a>
                </nav>

                <div class="pt-3 border-top border-secondary">
                    <a href="../logout.php" class="btn btn-danger w-100 text-white fw-bold">
                        <i class="fa-solid fa-right-from-bracket me-2"></i><span>Logout</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="col-md-9 col-lg-10 main-content">
            <!-- Top Navbar -->
            <div class="d-flex justify-content-between align-items-center bg-white p-3 rounded shadow-sm mb-4">
                <div class="d-flex align-items-center">
                    <button class="btn btn-outline-dark d-md-none me-3" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar" aria-controls="mobileSidebar">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    <h5 class="m-0 fw-bold me-3">Admin Control Center</h5>
                </div>

                <div class="d-flex align-items-center gap-2 gap-md-3">
                    <div class="d-flex align-items-center bg-light border px-3 py-1 rounded-pill notranslate">
                        <span class="small fw-bold me-2 text-primary" id="lang-en-label">EN</span>
                        <div class="form-check form-switch mb-0">
                            <input class="form-check-input" type="checkbox" role="switch" id="adminLangToggle" style="cursor: pointer;" onchange="changeAdminLanguage(this.checked)">
                        </div>
                        <span class="small fw-bold ms-1 text-muted" id="lang-am-label">አማ</span>
                    </div>

                    <span class="badge bg-primary px-3 py-2 fs-6">
                        👤 <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?>
                    </span>
                </div>
            </div>

<!-- ድብቅ የ Google Translate ኤለመንት -->
<div id="google_translate_element" style="display:none;"></div>

<script type="text/javascript">
function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    var domain = window.location.hostname;
    document.cookie = name + "=" + (value || "") + expires + "; path=/;";
    document.cookie = name + "=" + (value || "") + expires + "; domain=" + domain + "; path=/;";
    document.cookie = name + "=" + (value || "") + expires + "; domain=." + domain + "; path=/;";
}

function getCookie(name) {
    var cname = name + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(cname) == 0) return c.substring(cname.length, c.length);
    }
    return "";
}

function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'en',
        includedLanguages: 'en,am',
        autoDisplay: false,
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, 'google_translate_element');

    setTimeout(function() {
        var googCookie = getCookie('googtrans');
        var toggle = document.getElementById('adminLangToggle');
        if (googCookie && googCookie.includes('/am')) {
            if (toggle) toggle.checked = true;
            updateAdminLabelColors(true);
        } else {
            if (toggle) toggle.checked = false;
            updateAdminLabelColors(false);
        }
    }, 300);
}

function changeAdminLanguage(isAmharic) {
    var langCode = isAmharic ? 'am' : 'en';
    
    setCookie('googtrans', '/en/' + langCode, 30);
    updateAdminLabelColors(isAmharic);
    
    window.location.reload();
}

function updateAdminLabelColors(isAmharic) {
    var enLabel = document.getElementById('lang-en-label');
    var amLabel = document.getElementById('lang-am-label');
    
    if (enLabel && amLabel) {
        if (isAmharic) {
            enLabel.className = 'small fw-bold me-2 text-muted';
            amLabel.className = 'small fw-bold ms-1 text-primary';
        } else {
            enLabel.className = 'small fw-bold me-2 text-primary';
            amLabel.className = 'small fw-bold ms-1 text-muted';
        }
    }
}
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>