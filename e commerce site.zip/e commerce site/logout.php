<?php
session_start();

// ሁሉንም Session Data ማፅዳት
$_SESSION = array();

// Session Cookie ማጥፋት
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// Session ማጥፋት
session_destroy();

// ወደ መግቢያ ገፅ መመለስ
header("Location: login.php");
exit;
?>