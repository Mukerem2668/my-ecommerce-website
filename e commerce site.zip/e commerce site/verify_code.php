<?php
session_start();
require_once __DIR__ . '/config/db.php';

// የሰዓት ልዩነት እንዳይኖር Timezone ማስተካከያ
date_default_timezone_set('Africa/Addis_Ababa');

$email = $_SESSION['reset_email'] ?? '';

if (empty($email)) {
    header("Location: forgot_password.php");
    exit;
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input_code = trim($_POST['code'] ?? '');
    $new_password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // 1. ኮዱ ትክክለኛ እና ኤክስፓየር ያላደረገ መሆኑን ማረጋገጥ
    $current_time = date('Y-m-d H:i:s');
    $stmt = $conn->prepare("SELECT * FROM password_resets WHERE email = ? AND code = ? AND expires_at >= ?");
    $stmt->bind_param("sss", $email, $input_code, $current_time);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $error_message = "የስህተት ኮድ አስገብተዋል ወይም የኮዱ ጊዜ (15 ደቂቃ) አልፏል!";
    } elseif (strlen($new_password) < 6) {
        $error_message = "የይለፍ ቃል ቢያንስ 6 ቁምፊዎች መሆን አለበት!";
    } elseif ($new_password !== $confirm_password) {
        $error_message = "ያስገቧቸው የይለፍ ቃላት አይመሳሰሉም!";
    } else {
        // 2. የይለፍ ቃሉን Hash አድርጎ ማዘመን
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

        $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $update_stmt->bind_param("ss", $hashed_password, $email);
        $update_stmt->execute();
        $update_stmt->close();

        // ጥቅም ላይ የዋለውን ኮድ ማጥፋት
        $del_stmt = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
        $del_stmt->bind_param("s", $email);
        $del_stmt->execute();
        $del_stmt->close();

        unset($_SESSION['reset_email']);
        $_SESSION['msg'] = "የይለፍ ቃልዎ በትክክል ተቀይሯል! አሁን መግባት ይችላሉ።";
        header("Location: login.php");
        exit;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ኮድ ማረጋገጫ እና የይለፍ ቃል መቀየሪያ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light d-flex align-items-center justify-content-center min-vh-100">

<div class="card shadow border-0 p-4" style="max-width: 420px; width: 100%;">
    <div class="text-center mb-3">
        <i class="fa-solid fa-shield-halved fa-3x text-primary mb-2"></i>
        <h4 class="fw-bold">ኮዱን እና አዲስ የይለፍ ቃል ያስገቡ</h4>
        <small class="text-muted">ኮዱ ወደ <strong><?php echo htmlspecialchars($email); ?></strong> ተልኳል</small>
    </div>

    <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <form action="" method="POST">
        <div class="mb-3">
            <label class="form-label fw-bold">የተላከው 6-አሃዝ ኮድ</label>
            <input type="text" name="code" class="form-control text-center fw-bold fs-4" maxlength="6" placeholder="123456" required autocomplete="off">
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">አዲስ የይለፍ ቃል</label>
            <input type="password" name="password" class="form-control" placeholder="ቢያንስ 6 ቁምፊዎች" required>
        </div>

        <div class="mb-4">
            <label class="form-label fw-bold">የይለፍ ቃሉን ያረጋግጡ</label>
            <input type="password" name="confirm_password" class="form-control" placeholder="ድጋሚ ያስገቡ" required>
        </div>

        <button type="submit" class="btn btn-success w-100 fw-bold py-2 mb-3">
            <i class="fa-solid fa-check-circle me-1"></i> የይለፍ ቃል ቀይር
        </button>
    </form>
    
    <div class="d-flex justify-content-between align-items-center pt-2 border-top">
        <a href="login.php" class="text-decoration-none fw-semibold text-secondary small">
            <i class="fa-solid fa-arrow-left me-1"></i> መግቢያ (Login)
        </a>
        <a href="forgot_password.php" class="btn btn-outline-primary btn-sm fw-semibold">
            <i class="fa-solid fa-rotate-right me-1"></i> ኮድ ድጋሚ ላክ
        </a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>