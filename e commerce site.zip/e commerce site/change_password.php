<?php
session_start();
require_once __DIR__ . '/config/db.php';

// ተጠቃሚው Login ማድረጉን ማረጋገጥ
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error_msg = "እባክዎን ሁሉንም ቦታዎች ይሙሉ!";
    } elseif ($new_password !== $confirm_password) {
        $error_msg = "አዲሱ የይለፍ ቃል እና ማረጋገጫው አይመሳሰሉም!";
    } elseif (strlen($new_password) < 6) {
        $error_msg = "አዲሱ የይለፍ ቃል ከ 6 ፊደላት/ቁጥሮች ማነስ የለበትም!";
    } else {
        // የተጠቃሚውን ነባር የይለፍ ቃል ከ Database ማምጣት
        $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // የቀደመው የይለፍ ቃል ትክክል መሆኑን ማረጋገጥ
        if ($user && password_verify($current_password, $user['password'])) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $update_stmt->bind_param("si", $hashed_password, $user_id);
            if ($update_stmt->execute()) {
                $success_msg = "የይለፍ ቃልዎ በትክክል ተቀይሯል!";
            } else {
                $error_msg = "የይለፍ ቃሉን መቀየር አልተቻለም፣ እባክዎን እንደገና ይሞክሩ።";
            }
            $update_stmt->close();
        } else {
            $error_msg = "ያሰገቡት የቀደመ የይለፍ ቃል ስህተት ነው!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>የይለፍ ቃል ይቀይሩ (Change Password)</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold text-primary mb-0"><i class="fa-solid fa-key me-2"></i>የይለፍ ቃል ይቀይሩ</h4>
                <a href="profile.php" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-arrow-left me-1"></i> ወደ አካውንቴ</a>
            </div>

            <!-- Alert Messages -->
            <?php if ($success_msg): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $success_msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($error_msg): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $error_msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-body p-4">
                    <form action="change_password.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">የአሁኑ የይለፍ ቃል (Current Password)</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">አዲስ የይለፍ ቃል (New Password)</label>
                            <input type="password" name="new_password" class="form-control" placeholder="ቢያንስ 6 ፊደላት/ቁጥሮች" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold small">አዲሱን የይለፍ ቃል ያረጋግጡ (Confirm New Password)</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" name="change_password" class="btn btn-primary w-100 fw-bold">
                            <i class="fa-solid fa-lock-open me-1"></i> የይለፍ ቃል ቀይር
                        </button>
                    </form>
                </div>
                
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>