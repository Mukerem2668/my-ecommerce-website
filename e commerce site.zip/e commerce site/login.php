<?php
ob_start();
session_start();
include 'config/db.php';

$message = '';

if (isset($_POST['login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $selected_role = $_POST['role'];

    $result = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            if ($user['role'] !== $selected_role) {
                $message = '<div class="alert alert-warning">በተመረጠው የ ' . strtoupper($selected_role) . ' አካውንት የመግባት ፈቃድ የለዎትም!</div>';
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_role'] = $user['role'];

                if ($user['role'] === 'admin') {
                    header("Location: admin/dashboard.php");
                } else {
                    header("Location: index.php");
                }
                exit();
            }
        } else {
            $message = '<div class="alert alert-danger">የተሳሳተ ሚስጥር ቁጥር!</div>';
        }
    } else {
        $message = '<div class="alert alert-danger">በዚህ ኢሜይል የተመዘገበ አካውንት አልተገኘም!</div>';
    }
}

include 'includes/header.php';
?>

<!-- Google JavaScript SDK -->
<script src="https://accounts.google.com/gsi/client" async defer></script>

<div class="container my-5" style="max-width: 500px;">
    <div class="card shadow-sm border-0">
        <div class="card-body p-4">
            <h3 class="fw-bold text-center mb-4">ወደ አካውንትዎ ይግቡ</h3>
            <?php echo $message; ?>
            
            <form action="login.php" method="POST">
                <div class="mb-3 text-center p-2 bg-light rounded border">
                    <label class="form-label fw-bold d-block mb-2">እንደ ምን መግባት ይፈልጋሉ?</label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="loginCustomer" value="customer" checked>
                        <label class="form-check-label fw-bold" for="loginCustomer">Customer (ደንበኛ)</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="role" id="loginAdmin" value="admin">
                        <label class="form-check-label fw-bold text-danger" for="loginAdmin">Admin (አስተዳዳሪ)</label>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">ኢሜይል</label>
                    <input type="email" name="email" class="form-control" required placeholder="example@gmail.com">
                </div>
                
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <label class="form-label mb-0">ሚስጥር ቁጥር</label>
                        <a href="forgot_password.php" class="text-decoration-none small">የይለፍ ቃል ረስተዋል?</a>
                    </div>
                    <input type="password" name="password" class="form-control mt-1" required placeholder="******">
                </div>
                
                <button type="submit" name="login" class="btn btn-primary w-100 py-2 fw-bold">ግባ</button>
            </form>

            <div class="text-center my-3">
                <span class="text-muted small">ወይም</span>
            </div>

            <!-- Google Sign-In Button -->
            <div class="my-3 text-center">
                <div id="g_id_onload"
                     data-client_id="1041851260433-136ekh43jbgtt2iumu7mit7uo5u8df39.apps.googleusercontent.com"
                     data-callback="handleCredentialResponse">
                </div>
                <div class="g_id_signin d-flex justify-content-center" 
                     data-type="standard" 
                     data-shape="rectangular" 
                     data-theme="outline" 
                     data-size="large" 
                     data-width="100%">
                </div>
            </div>

            <hr>
            <p class="text-center mb-0">አካውንት የለዎትም? <a href="register.php" class="fw-bold">እዚህ ይመዝገቡ</a></p>
        </div>
    </div>
</div>

<!-- ከ Google የመጣውን Token ወደ Backend (google-login.php) መላኪያ Script -->
<script>
function handleCredentialResponse(response) {
    fetch('google-login.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'credential=' + encodeURIComponent(response.credential)
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            window.location.href = 'index.php';
        } else {
            alert('የ Google መግባት አልተሳካም፦ ' + data.message);
        }
    })
    .catch(err => {
        console.error('Error:', err);
    });
}
</script>

<?php include 'includes/footer.php'; ?>