<?php 
include 'config/db.php';
include 'includes/header.php'; 

// ቋንቋን ከ Session ማወቅ (በ header.php የተቀመጠውን)
$lang = $_SESSION['lang'] ?? 'am';

// 1. የፍለጋ መረጃዎችን መቀበል
$search   = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';

// 2. የ SQL Query ማዘጋጀት
$sql = "SELECT * FROM products WHERE 1=1";
$params = [];
$types = "";

if (!empty($search)) {
    $sql .= " AND (name LIKE ? OR description LIKE ?)";
    $search_param = "%" . $search . "%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

if (!empty($category)) {
    $sql .= " AND category = ?";
    $params[] = $category;
    $types .= "s";
}

$sql .= " ORDER BY id DESC";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// 3. የካቴጎሪዎችን ዝርዝር ከዳታቤዝ ማውጣት
$cat_query = "SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''";
$cat_result = $conn->query($cat_query);
?>

<!-- Hero Banner -->
<div class="bg-primary text-white text-center py-5 mb-4 shadow-sm">
    <div class="container">
        <h1 class="display-4 fw-bold">
            <?php echo ($lang == 'am') ? 'እንኳን ወደ MyStore በደህና መጡ' : 'Welcome to MyStore'; ?>
        </h1>
        <p class="lead">
            <?php echo ($lang == 'am') ? 'ምርጥ እቃዎችን በጥራት ያግኙ' : 'Discover the best quality products'; ?>
        </p>
    </div>
</div>

<div class="container mb-5">

    <!-- የፍለጋ እና የዳሰሳ አሞሌ (Search & Action Bar) -->
    <div class="card shadow-sm border-0 mb-4 bg-light">
        <div class="card-body p-3">
            <form action="" method="GET" class="row g-2 align-items-center">
                <!-- በስም መፈለጊያ -->
                <div class="col-md-5">
                    <input type="text" name="search" class="form-control" 
                           placeholder="<?php echo ($lang == 'am') ? 'የእቃ ስም ፈልግ...' : 'Search products...'; ?>" 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>

                <!-- በካቴጎሪ መፈለጊያ -->
                <div class="col-md-4">
                    <select name="category" class="form-select">
                        <option value=""><?php echo ($lang == 'am') ? 'ሁሉንም ካቴጎሪዎች' : 'All Categories'; ?></option>
                        <?php if ($cat_result && $cat_result->num_rows > 0): ?>
                            <?php while($cat_row = $cat_result->fetch_assoc()): ?>
                                <option value="<?php echo htmlspecialchars($cat_row['category']); ?>" <?php echo ($category === $cat_row['category']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars(ucfirst($cat_row['category'])); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <!-- አዝራሮች -->
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fa-solid fa-magnifying-glass me-1"></i> <?php echo ($lang == 'am') ? 'ፈልግ' : 'Search'; ?>
                    </button>
                    <a href="product.php" class="btn btn-outline-secondary" title="አፅዳ">
                        <i class="fa-solid fa-rotate-left"></i>
                    </a>
                </div>
            </form>

            <hr class="my-3">

            <!-- የደንበኛ አቋራጭ ሊንኮች እና የቋንቋ Toggle Switch -->
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <a href="profile.php" class="btn btn-outline-primary btn-sm fw-semibold">
                    <i class="fa-solid fa-user me-1"></i> <?php echo ($lang == 'am') ? 'የኔ አካውንት' : 'My Profile'; ?>
                </a>
                
                <div class="d-flex align-items-center gap-3">
                    

                    <a href="wishlist.php" class="btn btn-outline-danger btn-sm fw-semibold px-3">
                        <i class="fa-solid fa-heart me-1"></i> Wishlist
                    </a>
                    <a href="track_order.php" class="btn btn-outline-primary btn-sm fw-semibold px-3">
                        <i class="fa-solid fa-truck-fast me-1"></i> Track Order
                    </a>
                </div>
            </div>
        </div>
    </div>

    <h2 class="mb-4 text-center fw-bold">
        <?php echo ($lang == 'am') ? 'የእቃዎች ዝርዝር' : 'Product Collection'; ?>
    </h2>

    <!-- Product Grid -->
    <div class="row g-4">
        <?php
        if ($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="card h-100 shadow-sm border-0">
                        <a href="product-detail.php?id=<?php echo $row['id']; ?>" class="text-decoration-none text-dark">
                            <img src="<?php echo htmlspecialchars($row['image']); ?>" class="card-img-top" alt="Product" style="height: 200px; object-fit: cover;">
                        </a>
                        <div class="card-body d-flex flex-column text-center">
                            <h6 class="card-title fw-bold text-truncate mb-1">
                                <a href="product-details.php?id=<?php echo $row['id']; ?>" class="text-decoration-none text-dark">
                                    <?php echo htmlspecialchars($row['name']); ?>
                                </a>
                            </h6>
                            <p class="card-text text-success fw-bold fs-5 mb-3"><?php echo number_format($row['price'], 2); ?> $</p>
                            
                            <!-- Action Buttons -->
                            <div class="d-flex justify-content-between align-items-center mt-auto gap-2">
                                <form action="cart.php" method="POST" class="flex-grow-1">
                                    <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="quantity" value="1">
                                    <button type="submit" name="add_to_cart" class="btn btn-primary btn-sm w-100">
                                        <i class="fa-solid fa-cart-plus me-1"></i> <?php echo ($lang == 'am') ? 'ቅርጫት' : 'Cart'; ?>
                                    </button>
                                </form>
                                <a href="wishlist-action.php?action=add&product_id=<?php echo $row['id']; ?>" class="btn btn-outline-danger btn-sm" title="ወደ Wishlist ጨምር">
                                    <i class="fa-regular fa-heart"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<div class='col-12'><p class='text-center text-muted fs-5 my-5'>" . ($lang == 'am' ? 'ምንም የተገኘ እቃ የለም' : 'No products found') . "</p></div>";
        }
        ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>