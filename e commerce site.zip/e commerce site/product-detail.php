<?php 
include 'config/db.php';
include 'includes/header.php'; 

// 1. Get & Validate Product ID
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($product_id <= 0) {
    echo "<div class='container my-5'><div class='alert alert-danger'>ትክክለኛ ያልሆነ የምርት መለያ (Product ID)!</div></div>";
    include 'includes/footer.php';
    exit;
}

$message = "";
$msg_type = "";

// 2. Handle Review Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $user_name = trim($_POST['user_name']);
    $rating    = intval($_POST['rating']);
    $comment   = trim($_POST['comment']);

    if (empty($user_name) || empty($comment) || $rating < 1 || $rating > 5) {
        $message = "እባክዎን ሁሉንም መስኮች በትክክል ይሙሉ እና ከ 1 እስከ 5 ኮከብ ይምረጡ!";
        $msg_type = "danger";
    } else {
        $stmt_ins = $conn->prepare("INSERT INTO reviews (product_id, user_name, rating, comment) VALUES (?, ?, ?, ?)");
        $stmt_ins->bind_param("isis", $product_id, $user_name, $rating, $comment);
        
        if ($stmt_ins->execute()) {
            $message = "አስተያየትዎ እና ደረጃዎ በስኬት ተመዝግቧል! እናመሰግናለን።";
            $msg_type = "success";
        } else {
            $message = "ስህተት ተፈጥሯል፦ አስተያየቱን ማስገባት አልተቻለም።";
            $msg_type = "danger";
        }
        $stmt_ins->close();
    }
}

// 3. Fetch Product Details (Prepared Statement for Security)
$stmt_prod = $conn->prepare("SELECT p.*, c.category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ?");
$stmt_prod->bind_param("i", $product_id);
$stmt_prod->execute();
$product = $stmt_prod->get_result()->fetch_assoc();
$stmt_prod->close();

if (!$product) {
    echo "<div class='container my-5'><div class='alert alert-danger'>እቃው አልተገኘም!</div></div>";
    include 'includes/footer.php';
    exit;
}

// 4. Fetch Reviews and Calculate Average Rating
$stmt_rev = $conn->prepare("SELECT * FROM reviews WHERE product_id = ? ORDER BY id DESC");
$stmt_rev->bind_param("i", $product_id);
$stmt_rev->execute();
$reviews_result = $stmt_rev->get_result();

$total_reviews = $reviews_result->num_rows;
$avg_rating = 0;
$sum_rating = 0;
$reviews_list = [];

while ($row = $reviews_result->fetch_assoc()) {
    $sum_rating += $row['rating'];
    $reviews_list[] = $row;
}
$stmt_rev->close();

if ($total_reviews > 0) {
    $avg_rating = round($sum_rating / $total_reviews, 1);
}

// Image Path Check
$image_path = 'uploads/' . basename($product['image']);
if (!empty($product['image']) && file_exists($image_path)) {
    $display_img = $image_path;
} elseif (!empty($product['image']) && file_exists($product['image'])) {
    $display_img = $product['image'];
} else {
    $display_img = 'https://via.placeholder.com/350x300?text=No+Image';
}
?>

<div class="container my-5">

    <!-- Alert Messages -->
    <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $msg_type; ?> alert-dismissible fade show shadow-sm mb-4" role="alert">
            <i class="fa-solid fa-circle-info me-2"></i><?php echo htmlspecialchars($message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Product Details Card -->
    <div class="row bg-white p-4 shadow-sm rounded align-items-center mb-5">
        <div class="col-md-5 text-center bg-light rounded p-3">
            <img src="<?php echo htmlspecialchars($display_img); ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($product['name']); ?>" style="max-height: 350px; object-fit: contain;">
        </div>
        <div class="col-md-7 ps-md-4">
            <span class="badge bg-secondary mb-2"><?php echo htmlspecialchars($product['category_name'] ?? 'General'); ?></span>
            <h2 class="fw-bold"><?php echo htmlspecialchars($product['name']); ?></h2>
            
            <!-- Rating Star Display -->
            <div class="d-flex align-items-center my-2">
                <div class="text-warning me-2 fs-5">
                    <?php
                    for ($i = 1; $i <= 5; $i++) {
                        if ($i <= floor($avg_rating)) {
                            echo '<i class="fa-solid fa-star"></i>';
                        } elseif ($i - $avg_rating < 1 && $i - $avg_rating > 0) {
                            echo '<i class="fa-solid fa-star-half-stroke"></i>';
                        } else {
                            echo '<i class="fa-regular fa-star"></i>';
                        }
                    }
                    ?>
                </div>
                <span class="fw-bold fs-5 text-dark me-2"><?php echo $avg_rating; ?></span>
                <span class="text-muted small">(ከ <?php echo $total_reviews; ?> አስተያየቶች)</span>
            </div>

            <h3 class="text-primary fw-bold my-3">$<?php echo number_format($product['price'], 2); ?></h3>
            <p class="text-muted"><?php echo nl2br(htmlspecialchars($product['description'] ?? '')); ?></p>

            <!-- Add to Cart Form -->
            <form action="cart.php" method="POST" class="mt-4">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <div class="row g-3 align-items-center mb-3">
                    <div class="col-auto">
                        <label for="quantity" class="col-form-label fw-bold">ብዛት (Quantity):</label>
                    </div>
                    <div class="col-auto">
                        <input type="number" id="quantity" name="quantity" class="form-control" value="1" min="1" style="width: 80px;">
                    </div>
                </div>
                <button type="submit" name="add_to_cart" class="btn btn-primary btn-lg px-4 me-2 shadow-sm">
                    <i class="fa-solid fa-cart-plus me-1"></i> ወደ ቅርጫት ጨምር
                </button>
            </form>
        </div>
    </div>

    <!-- REVIEWS SECTION -->
    <div class="row g-4">
        
        <!-- Display Existing Reviews (Left Column) -->
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm p-4 h-100">
                <h5 class="fw-bold mb-4 border-bottom pb-2">
                    <i class="fa-solid fa-comments me-2 text-primary"></i> የደንበኞች አስተያየቶች (<?php echo $total_reviews; ?>)
                </h5>

                <?php if ($total_reviews > 0): ?>
                    <div class="d-flex flex-column gap-3">
                        <?php foreach ($reviews_list as $rev): ?>
                            <div class="border-bottom pb-3">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <h6 class="fw-bold mb-0 text-dark">
                                        <i class="fa-solid fa-user-circle text-secondary me-1"></i>
                                        <?php echo htmlspecialchars($rev['user_name']); ?>
                                    </h6>
                                    <small class="text-muted"><?php echo date('M d, Y', strtotime($rev['created_at'])); ?></small>
                                </div>
                                <div class="text-warning small mb-2">
                                    <?php
                                    for ($s = 1; $s <= 5; $s++) {
                                        echo ($s <= $rev['rating']) ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
                                    }
                                    ?>
                                </div>
                                <p class="text-secondary mb-0 small"><?php echo nl2br(htmlspecialchars($rev['comment'])); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="fa-regular fa-comment-dots fa-3x mb-3 text-secondary"></i>
                        <p class="mb-0">ለዚህ እቃ እስካሁን የተሰጠ አስተያየት የለም። የመጀመሪያው አስተያየት ሰጪ ይሁኑ!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Submit Review Form (Right Column) -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm p-4">
                <h5 class="fw-bold mb-3 border-bottom pb-2">
                    <i class="fa-solid fa-pen-to-square me-2 text-primary"></i> አስተያየት እና ደረጃ ይስጡ
                </h5>

                <form action="product-detail.php?id=<?php echo $product_id; ?>" method="POST">
                    
                    <div class="mb-3">
                        <label class="form-label small fw-bold">ስምዎ</label>
                        <input type="text" name="user_name" class="form-control" placeholder="ምሳሌ፦ አበበ" required value="<?php echo htmlspecialchars($_SESSION['first_name'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">ደረጃ ( Rating )</label>
                        <select name="rating" class="form-select text-warning fw-bold" required>
                            <option value="5">⭐⭐⭐⭐⭐ (5/5 - በጣም ጥሩ)</option>
                            <option value="4">⭐⭐⭐⭐ (4/5 - ጥሩ)</option>
                            <option value="3">⭐⭐⭐ (3/5 - መካከለኛ)</option>
                            <option value="2">⭐⭐ (2/5 - ዝቅተኛ)</option>
                            <option value="1">⭐ (1/5 - በጣም ዝቅተኛ)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">አስተያየትዎ</label>
                        <textarea name="comment" class="form-control" rows="4" placeholder="ስለ እቃው ጥራት እና አገልግሎት ያለዎትን አስተያየት እዚህ ይፃፉ..." required></textarea>
                    </div>

                    <button type="submit" name="submit_review" class="btn btn-primary w-100 fw-bold shadow-sm">
                        <i class="fa-solid fa-paper-plane me-1"></i> አስተያየት ላክ
                    </button>
                </form>
            </div>
        </div>

    </div>
</div>

<?php include 'includes/footer.php'; ?>