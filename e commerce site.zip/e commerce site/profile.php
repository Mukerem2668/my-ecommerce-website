<?php
session_start();
require_once __DIR__ . '/config/db.php';
include 'includes/header.php'; 

// ተጠቃሚው Login ማድረጉን ማረጋገጥ
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

// 1. የፕሮፋይል መረጃ ማዘመኛ (Update Profile)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone'] ?? '');

    if (!empty($name)) {
        $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $phone, $user_id);
        if ($stmt->execute()) {
            $success_msg = "መረጃዎ በትክክል ተዘምኗል!";
        } else {
            $error_msg = "ስህተት ተከሰቷል፣ እባክዎን እንደገና ይሞክሩ።";
        }
        $stmt->close();
    } else {
        $error_msg = "ስም ባዶ መሆን አይችልም!";
    }
}

// 2. የተጠቃሚውን መረጃ ከ Database ማምጣት
$stmt = $conn->prepare("SELECT name, email, phone, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// 3. የደንበኛውን የትዕዛዝ ታሪክ (Order History) ማምጣት
$order_stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
$order_stmt->bind_param("i", $user_id);
$order_stmt->execute();
$orders = $order_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>የኔ አካውንት (My Profile)</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container py-5">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold text-primary"><i class="fa-solid fa-user-circle me-2"></i>የኔ አካውንት</h3>
        <a href="index.php" class="btn btn-outline-secondary"><i class="fa-solid fa-house me-1"></i>ወደ መነሻ ገጽ</a>
    </div>

    <!-- Alert Messages -->
    <?php if ($success_msg): ?>
        <div class="alert alert-success alert-dismissible fade show"><?php echo $success_msg; ?><button class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?php echo $error_msg; ?><button class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- 1. Personal Information Card -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-body p-4 text-center">
                    <div class="mb-3">
                        <i class="fa-solid fa-circle-user fa-5x text-secondary"></i>
                    </div>
                    <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($user['name'] ?? ''); ?></h5>
                    <p class="text-muted small mb-3"><?php echo htmlspecialchars($user['email'] ?? ''); ?></p>
                    <span class="badge bg-primary-subtle text-primary mb-3">ደንበኛ (Customer)</span>
                    <hr>
                    
                    <form action="" method="POST" class="text-start mb-3">
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">ሙሉ ስም</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold small">ስልክ ቁጥር</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="0911...">
                        </div>
                        <button type="submit" name="update_profile" class="btn btn-primary w-100 fw-bold mb-2">
                            <i class="fa-solid fa-save me-1"></i> መረጃ አዝምን
                        </button>
                    </form>

                    <!-- የይለፍ ቃል መቀየሪያ ሊንክ -->
                    <a href="change_password.php" class="btn btn-outline-danger w-100 btn-sm fw-semibold">
                        <i class="fa-solid fa-key me-1"></i> የይለፍ ቃል መቀየር ይፈልጋሉ?
                    </a>
                </div>
            </div>
        </div>

        <!-- 2. Order History Table -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-header bg-white py-3 border-0">
                    <h5 class="fw-bold mb-0 text-dark"><i class="fa-solid fa-box-open me-2 text-primary"></i>የትዕዛዞች ታሪክ (Order History)</h5>
                </div>
                <div class="card-body p-0">
                    <?php if ($orders && $orders->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Order ID</th>
                                        <th>ጠቅላላ ዋጋ</th>
                                        <th>ሁኔታ (Status)</th>
                                        <th class="text-center">ደረሰኝ (Invoice)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($order = $orders->fetch_assoc()): ?>
                                        <tr>
                                            <td class="fw-bold">#ORD-<?php echo sprintf("%04d", $order['id']); ?></td>
                                            <td class="fw-semibold text-success"><?php echo number_format($order['amount'] ?? 0, 2); ?> ETB</td>
                                            <td>
                                                <?php
                                                $status = $order['status'] ?? 'Pending';
                                                $badge = 'bg-secondary';
                                                if ($status == 'Pending') $badge = 'bg-warning text-dark';
                                                elseif ($status == 'Approved') $badge = 'bg-info text-dark';
                                                elseif ($status == 'Completed' || $status == 'Delivered') $badge = 'bg-success';
                                                elseif ($status == 'Cancelled') $badge = 'bg-danger';
                                                ?>
                                                <span class="badge <?php echo $badge; ?> px-2 py-1"><?php echo htmlspecialchars($status); ?></span>
                                            </td>
                                            <td class="text-center">
                                                <a href="invoice.php?order_id=<?php echo $order['id']; ?>" target="_blank" class="btn btn-sm btn-outline-primary fw-bold">
                                                    <i class="fa-solid fa-file-invoice me-1"></i> ደረሰኝ ይመልከቱ
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fa-solid fa-cart-flatbed fa-3x text-muted mb-3"></i>
                            <p class="text-muted">እስከ አሁን ምንም ያዘዙት እቃ የለም።</p>
                            <a href="index.php" class="btn btn-primary btn-sm">እቃዎችን ይመልከቱ</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>