<?php
ob_start();
session_start();
include 'config/db.php';

if (!isset($_SESSION['temp_user'])) {
    header("Location: register.php");
    exit();
}

$user_data = $_SESSION['temp_user'];
$error_msg = '';

if (isset($_POST['confirm_verification'])) {
    $name = $conn->real_escape_string($user_data['name']);
    $email = $conn->real_escape_string($user_data['email']);
    $password = $conn->real_escape_string($user_data['password']);

    // Database ውስጥ ማስገባት
    $sql = "INSERT INTO users (name, email, password, role, is_verified) 
            VALUES ('$name', '$email', '$password', 'customer', 1)";

    if ($conn->query($sql)) {
        unset($_SESSION['temp_user']);
        $_SESSION['user_id'] = $conn->insert_id;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_role'] = 'customer';

        header("Location: index.php");
        exit();
    } else {
        $error_msg = '<div class="alert alert-danger">የ Database ስህተት፦ ' . $conn->error . '</div>';
    }
}

include 'includes/header.php';
?>

<div class="container my-5" style="max-width: 550px;">
    <div class="card shadow border-0 text-center p-4">
        <div class="card-body">
            <i class="fa-brands fa-google text-danger display-4 mb-3"></i>
            <h4 class="fw-bold">የ Google አካውንት ማረጋገጫ</h4>
            <?php echo $error_msg; ?>
            <p class="text-muted">
                ያስገቡትን ኢሜይል <strong>(<?php echo htmlspecialchars($user_data['email']); ?>)</strong> ማረጋገጥ ይፈልጋሉ?
            </p>

            <form action="verify.php" method="POST" class="mt-4">
                <button type="submit" name="confirm_verification" class="btn btn-success w-100 py-2 fw-bold">
                    ምዝገባውን ጨርስ (Complete Registration)
                </button>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>