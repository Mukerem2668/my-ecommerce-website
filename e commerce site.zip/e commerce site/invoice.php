<?php
session_start();
include 'config/db.php';

// አድሚን መሆኑን ማረጋገጥ
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    // header("Location: login.php");
}

// የ order_id መኖሩን ማረጋገጥ
if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    die("ትክክለኛ የትዕዛዝ ቁጥር (Order ID) አልተገኘም።");
}

$order_id = intval($_GET['order_id']);

// የትዕዛዙን መረጃ ከ Database መፈለግ
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("የተፈለገው ትዕዛዝ በስርዓቱ ውስጥ አልተገኘም።");
}

$order = $result->fetch_assoc();
$stmt->close();

// የማድረሻ ቦታዎችን እና የእቃ ስሞችን መለየት
$raw_product_name = $order['product_name'] ?? 'N/A';
$city = $order['city'] ?? '';
$area = $order['area'] ?? '';

// Regex በመጠቀም በ product_name ውስጥ የተሸሸገ አድራሻ ካለ ማውጣት
$clean_product_name = trim(preg_replace('/\[የማድረሻ ቦታ:.*?\]/su', '', $raw_product_name));

if (preg_match('/\[የማድረሻ ቦታ:-\s*([\s\S]*?)\s*-\s*([\s\S]*?)\]/u', $raw_product_name, $matches)) {
    if (empty($city) || $city === 'N/A') {
        $city = trim($matches[1]);
    }
    if (empty($area) || $area === 'N/A') {
        $area = trim($matches[2]);
    }
}

if (empty($city)) $city = 'N/A';
if (empty($area)) $area = 'N/A';
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ደረሰኝ - Order #<?php echo $order['id']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .invoice-card {
            max-width: 800px;
            margin: 30px auto;
            background: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.05);
        }
        .invoice-header {
            border-bottom: 2px solid #eee;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .table th {
            background-color: #f8f9fa;
        }
        /* ገፁ ሲታተም የማይፈለጉ ነገሮችን መደበቂያ (Media Query) */
        @media print {
            body {
                background-color: #fff;
            }
            .no-print {
                display: none !important;
            }
            .invoice-card {
                box-shadow: none;
                border: none;
                padding: 0;
                margin: 0;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- የህትመት እና የመመለሻ አዝራሮች -->
    <div class="text-center mt-4 no-print">
        <button onclick="window.print()" class="btn btn-primary px-4 me-2">
            <i class="fa-solid fa-print me-2"></i> ደረሰኝ አትም (Print Invoice)
        </button>
        <button onclick="window.close()" class="btn btn-outline-secondary px-4">
            <i class="fa-solid fa-xmark me-2"></i> ዝጋ
        </button>
    </div>

    <!-- የደረሰኙ ዋና አካል -->
    <div class="invoice-card">
        <!-- 1. የHeader ክፍል -->
        <div class="invoice-header d-flex justify-content-between align-items-center">
            <div>
                <h2 class="fw-bold text-primary m-0"><i class="fa-solid fa-store me-2"></i> የሱቅ ስም</h2>
                <small class="text-muted">የኦንላይን ገበያ ማዕከል</small>
            </div>
            <div class="text-end">
                <h4 class="fw-bold text-uppercase m-0">የክፍያ ደረሰኝ</h4>
                <span class="text-muted small">ቁጥር፦ #INV-<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></span>
            </div>
        </div>

        <!-- 2. የደንበኛ እና የትዕዛዝ መረጃ -->
        <div class="row mb-4">
            <div class="col-6">
                <h6 class="fw-bold text-secondary text-uppercase small mb-2">ለደንበኛ፦</h6>
                <h5 class="fw-bold mb-1"><?php echo htmlspecialchars(($order['first_name'] ?? '') . ' ' . ($order['last_name'] ?? '')); ?></h5>
                <p class="mb-1 text-muted"><i class="fa-solid fa-phone me-1 small"></i> <?php echo htmlspecialchars($order['phone'] ?? 'N/A'); ?></p>
                <p class="mb-1 text-muted"><i class="fa-solid fa-envelope me-1 small"></i> <?php echo htmlspecialchars($order['email'] ?? 'N/A'); ?></p>
                <p class="mb-0 text-muted"><i class="fa-solid fa-location-dot me-1 small"></i> <?php echo htmlspecialchars($city . ', ' . $area); ?></p>
            </div>
            <div class="col-6 text-end">
                <h6 class="fw-bold text-secondary text-uppercase small mb-2">የትዕዛዝ ዝርዝር፦</h6>
                <p class="mb-1"><strong>የትዕዛዝ ID፦</strong> #<?php echo $order['id']; ?></p>
                <p class="mb-1"><strong>ቀን፦</strong> <?php echo isset($order['created_at']) ? date('M d, Y - h:i A', strtotime($order['created_at'])) : date('M d, Y'); ?></p>
                <p class="mb-1"><strong>Pickup Code፦</strong> <span class="badge bg-dark font-monospace"><?php echo htmlspecialchars($order['pickup_code'] ?? 'N/A'); ?></span></p>
                <p class="mb-0"><strong>Transaction Ref፦</strong> <code class="text-primary fw-bold"><?php echo htmlspecialchars($order['tx_ref'] ?? 'N/A'); ?></code></p>
            </div>
        </div>

        <!-- 3. የተገዙ እቃዎች ሰንጠረዥ -->
        <div class="table-responsive mb-4">
            <table class="table table-bordered align-middle">
                <thead>
                    <tr>
                        <th style="width: 50%;">የዕቃው ስም (Description)</th>
                        <th class="text-center">ሁኔታ (Status)</th>
                        <th class="text-end">አጠቃላይ ዋጋ</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <strong><?php echo htmlspecialchars($clean_product_name); ?></strong>
                        </td>
                        <td class="text-center">
                            <?php 
                            $st = strtolower($order['status'] ?? 'pending');
                            if ($st === 'completed' || $st === 'paid'): ?>
                                <span class="badge bg-success">ተከፍሏል (Paid)</span>
                            <?php elseif (in_array($st, ['failed', 'rejected', 'cancelled'])): ?>
                                <span class="badge bg-danger">ተሰርዟል</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark"><?php echo htmlspecialchars($order['status']); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end fw-bold">
                            <?php echo number_format($order['amount'] ?? 0, 2); ?> ETB
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- 4. የድምር ሂሳብ ማጠቃለያ -->
        <div class="row justify-content-end mb-4">
            <div class="col-md-5">
                <table class="table table-borderless">
                    <tr>
                        <td class="text-start">የእቃዎች ዋጋ፦</td>
                        <td class="text-end fw-bold"><?php echo number_format($order['amount'] ?? 0, 2); ?> ETB</td>
                    </tr>
                    <tr>
                        <td class="text-start">የማድረሻ ክፍያ (Delivery):</td>
                        <td class="text-end fw-bold">0.00 ETB</td>
                    </tr>
                    <tr class="border-top">
                        <td class="text-start fs-5 fw-bold">ጠቅላላ ድምር፦</td>
                        <td class="text-end fs-5 fw-bold text-success"><?php echo number_format($order['amount'] ?? 0, 2); ?> ETB</td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- 5. የእግር ማስታወሻ (Footer) -->
        <div class="border-top pt-3 mt-4 text-center text-muted small">
            <p class="mb-1">ስለገዙን እናመሰግናለን!</p>
            <p class="mb-0">ማንኛውም ጥያቄ ካለዎት በ support mukerem26@gmail.com ወይም በ +251 926680499 ያግኙን።</p>
        </div>
    </div>
</div>

</body>
</html>