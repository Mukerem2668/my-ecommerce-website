<?php 
include 'config/db.php';
include 'includes/header.php'; 

// 1. Filter Input Handling
$category_id = isset($_GET['category']) ? trim($_GET['category']) : '';
$search      = isset($_GET['search']) ? trim($_GET['search']) : '';
$min_price   = isset($_GET['min_price']) && $_GET['min_price'] !== '' ? floatval($_GET['min_price']) : '';
$max_price   = isset($_GET['max_price']) && $_GET['max_price'] !== '' ? floatval($_GET['max_price']) : '';

// 2. Dynamic SQL Query Construction with Prepared Statements
$where_clauses = ["1=1"];
$params        = [];
$types         = "";

if (!empty($category_id)) {
    $where_clauses[] = "category_id = ?";
    $params[]        = intval($category_id);
    $types          .= "i";
}

if (!empty($search)) {
    $where_clauses[] = "(name LIKE ? OR description LIKE ?)";
    $search_param    = "%" . $search . "%";
    $params[]        = $search_param;
    $params[]        = $search_param;
    $types          .= "ss";
}

if ($min_price !== '') {
    $where_clauses[] = "price >= ?";
    $params[]        = $min_price;
    $types          .= "d";
}

if ($max_price !== '') {
    $where_clauses[] = "price <= ?";
    $params[]        = $max_price;
    $types          .= "d";
}

$sql = "SELECT * FROM products WHERE " . implode(" AND ", $where_clauses) . " ORDER BY id DESC";

$stmt = $conn->prepare($sql);
if (!empty($types)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!-- Custom CSS -->
<style>
    .product-card {
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
    }
    .product-img-container {
        overflow: hidden;
        background-color: #f8f9fa;
        border-top-left-radius: 0.375rem;
        border-top-right-radius: 0.375rem;
    }
    .product-img-container img {
        transition: transform 0.3s ease;
    }
    .product-card:hover .product-img-container img {
        transform: scale(1.05);
    }
    .category-link.active {
        background-color: #0d6efd;
        color: #fff !important;
        font-weight: 600;
    }
</style>

<div class="container my-5">
    <div class="row g-4">
        <!-- Sidebar Filter -->
        <div class="col-lg-3 col-md-4">
            
            <!-- Search & Price Filter Form -->
            <div class="card shadow-sm border-0 mb-3">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-3 text-dark">
                        <i class="fa-solid fa-magnifying-glass me-2 text-primary"></i> እቃ ፈልግ እና አጣራ
                    </h6>
                    <form action="product.php" method="GET">
                        <?php if (!empty($category_id)): ?>
                            <input type="hidden" name="category" value="<?php echo htmlspecialchars($category_id); ?>">
                        <?php endif; ?>
                        
                        <!-- Search Box -->
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">የምርት ስም</label>
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="ምሳሌ፦ ጫማ..." value="<?php echo htmlspecialchars($search); ?>">
                        </div>

                        <!-- Price Range -->
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">የዋጋ መጠን ($)</label>
                            <div class="row g-2">
                                <div class="col-6">
                                    <input type="number" step="0.01" name="min_price" class="form-control form-control-sm" placeholder="ከ" value="<?php echo $min_price !== '' ? $min_price : ''; ?>">
                                </div>
                                <div class="col-6">
                                    <input type="number" step="0.01" name="max_price" class="form-control form-control-sm" placeholder="እስከ" value="<?php echo $max_price !== '' ? $max_price : ''; ?>">
                                </div>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-sm fw-semibold">
                                <i class="fa-solid fa-filter me-1"></i> አጣራ (Filter)
                            </button>
                            <a href="product.php" class="btn btn-outline-secondary btn-sm fw-semibold">
                                <i class="fa-solid fa-rotate-left me-1"></i> አፅዳ (Reset)
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Categories Card -->
            <div class="card shadow-sm border-0 sticky-top" style="top: 20px; z-index: 10;">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-3 d-flex align-items-center text-dark">
                        <i class="fa-solid fa-list me-2 text-primary"></i> ምድቦች
                    </h6>
                    <div class="list-group list-group-flush rounded-3">
                        <a href="product.php" class="list-group-item list-group-item-action category-link border-0 rounded-2 mb-1 <?php echo empty($category_id) ? 'active' : ''; ?>">
                            <i class="fa-solid fa-layer-group me-2"></i> ሁሉንም አሳይ
                        </a>

                        <?php
                        $cat_sql = "SELECT * FROM categories";
                        $cat_result = $conn->query($cat_sql);
                        if ($cat_result && $cat_result->num_rows > 0) {
                            while($cat = $cat_result->fetch_assoc()) {
                                $is_active = ($category_id == $cat['id']) ? 'active' : '';
                                // Preserve search params when changing category
                                $cat_url = "product.php?category=" . $cat['id'];
                                if(!empty($search)) $cat_url .= "&search=" . urlencode($search);
                                if($min_price !== '') $cat_url .= "&min_price=" . $min_price;
                                if($max_price !== '') $cat_url .= "&max_price=" . $max_price;

                                echo '<a href="'.$cat_url.'" class="list-group-item list-group-item-action category-link border-0 rounded-2 mb-1 '.$is_active.'">
                                        <i class="fa-solid fa-angle-right me-2 small"></i> '.htmlspecialchars($cat['category_name']).'
                                      </a>';
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>

            <!-- Dashboard Link -->
            <div class="mt-3">
                <a href="index.php" class="btn btn-outline-secondary w-100 py-2 shadow-sm fw-semibold">
                    <i class="fa-solid fa-house me-2"></i> ወደ ዋናው ገፅ (Dashboard)
                </a>
            </div>
        </div>

        <!-- Main Products Display -->
        <div class="col-lg-9 col-md-8"> 
            <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                <h4 class="fw-bold m-0 text-dark">
                    <i class="fa-solid fa-store me-2 text-primary"></i> የእቃዎች ዝርዝር
                </h4>
                <span class="badge bg-primary rounded-pill fs-6 fw-normal">
                    <?php echo $result ? $result->num_rows : 0; ?> እቃዎች
                </span>
            </div>

            <div class="row g-4">
                <?php
                if ($result && $result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $stock_count = isset($row['stock']) ? intval($row['stock']) : 0;
                        ?>
                        <div class="col-12 col-sm-6 col-lg-4">
                            <div class="card h-100 border-0 shadow-sm product-card">
                                <div class="product-img-container text-center p-3">
                                    <img src="<?php echo htmlspecialchars($row['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($row['name']); ?>" style="height: 180px; object-fit: contain;">
                                </div>
                                <div class="card-body d-flex flex-column text-center p-3">
                                    <h6 class="card-title fw-bold text-truncate mb-2" title="<?php echo htmlspecialchars($row['name']); ?>">
                                        <?php echo htmlspecialchars($row['name']); ?>
                                    </h6>
                                    <p class="text-primary fs-5 fw-bold mb-2">$<?php echo number_format($row['price'], 2); ?></p>
                                    
                                    <!-- Stock Status Badge -->
                                    <div class="mb-3">
                                        <?php if ($stock_count > 0): ?>
                                            <span class="badge bg-success-subtle text-success border border-success small">በStock አለ (<?php echo $stock_count; ?>)</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger border border-danger small">እቃው አልቋል (Out of Stock)</span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="mt-auto d-flex flex-column gap-2">
                                        <div class="d-flex gap-2">
                                            <a href="product-detail.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-secondary btn-sm w-50 fw-semibold">
                                                <i class="fa-solid fa-eye me-1"></i> ዝርዝር
                                            </a>
                                            <a href="wishlist-action.php?action=add&product_id=<?php echo $row['id']; ?>" class="btn btn-outline-danger btn-sm w-50 fw-semibold">
                                                <i class="fa-solid fa-heart me-1"></i> Wishlist
                                            </a>
                                        </div>

                                        <?php if ($stock_count > 0): ?>
                                            <a href="cart.php?add=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm w-100 fw-semibold">
                                                <i class="fa-solid fa-cart-plus me-1"></i> ወደ ቅርጫት ጨምር
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-secondary btn-sm w-100 fw-semibold" disabled>
                                                <i class="fa-solid fa-ban me-1"></i> አልቋል
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                } else {
                    echo "<div class='col-12'><div class='alert alert-info text-center py-4 shadow-sm border-0'><i class='fa-solid fa-circle-info me-2 fs-5'></i> ምንም የተገኘ እቃ የለም።</div></div>";
                }
                $stmt->close();
                ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>