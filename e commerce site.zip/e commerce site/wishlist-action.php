<?php
session_start();
include 'config/db.php';

// 1. Session መኖሩን ማረጋገጥ
if (!isset($_SESSION['user_id'])) {
    die("<b>Error:</b> ተጠቃሚው Login አላደረገም! (SESSION user_id አልተገኘም)");
}

$user_id = $_SESSION['user_id'];

if (isset($_GET['action']) && isset($_GET['product_id'])) {
    $product_id = intval($_GET['product_id']);
    $action = $_GET['action'];

    if ($action === 'add') {
        // አስቀድሞ መኖሩን ማረጋገጥ
        $check = $conn->prepare("SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?");
        $check->bind_param("ii", $user_id, $product_id);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows == 0) {
            $stmt = $conn->prepare("INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $user_id, $product_id);
            
            if ($stmt->execute()) {
                echo "<b>Success:</b> እቃው በውጤታማነት ወደ Wishlist ተጨምሯል!<br>";
                echo "<a href='product.php'>ወደ እቃዎች ተመለስ</a> | 
                <a href='wishlist.php'>ወደ Wishlist ሂድ</a>";
            } else {
                echo "<b>Database Error:</b> " . $conn->error;
            }
        } else {
            echo "እቃው አስቀድሞ በ Wishlist ውስጥ አለ።<br>";
            echo "<a href='product.php'>ወደ እቃዎች ተመለስ</a>";
        }
    }
} else {
    echo "<b>Error:</b> አስፈላጊዎቹ parameters (action ወይም product_id) አልተላኩም።";
}
?>