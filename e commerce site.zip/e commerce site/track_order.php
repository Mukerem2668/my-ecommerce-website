<?php
session_start();
require_once 'config.php';
include 'includes/header.php'; 

$order_details = null;
$searched = false;

if (isset($_POST['track_order'])) {
    $search_input = trim($_POST['search_input']); 
    $searched = true;

    if (!empty($search_input)) {
        // በ Transaction ID, Phone ወይም በ Order ID መፈለግ
        $stmt = $conn->prepare("SELECT * FROM orders WHERE tx_ref = ? OR phone = ? OR id = ? ORDER BY id DESC LIMIT 1");
        $stmt->bind_param("sss", $search_input, $search_input, $search_input);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows > 0) {
            $order_details = $res->fetch_assoc();
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ትዕዛዝ መከታተያ (Track Order)</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow border-0 p-4">
                <h4 class="fw-bold text-center mb-3">የትዕዛዝዎ ሁኔታ ይከታተሉ</h4>
                
                <form action="" method="POST" class="mb-4">
                    <div class="input-group">
                        <input type="text" name="search_input" class="form-control" placeholder="Transaction ID, ስልክ ቁጥር ወይም Order ID" value="<?php echo htmlspecialchars($_POST['search_input'] ?? ''); ?>" required>
                        <button type="submit" name="track_order" class="btn btn-primary fw-bold">ፈልግ</button>
                    </div>
                </form>

                <?php if ($searched): ?>
                    <?php if ($order_details): 
                        $status = trim($order_details['status'] ?? 'Pending');
                        $admin_message = trim($order_details['admin_message'] ?? '');
                    ?>
                        <div class="border rounded p-3 bg-white shadow-sm">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="fw-bold">ትዕዛዝ #<?php echo htmlspecialchars($order_details['id']); ?></span>
                                
                                <!-- Status ማሳያ -->
                                <?php if (strcasecmp($status, 'Paid') == 0 || strcasecmp($status, 'Completed') == 0): ?>
                                    <span class="badge bg-success fs-6"><i class="fa-solid fa-circle-check me-1"></i> Order Success</span>
                                <?php elseif (strcasecmp($status, 'Failed') == 0 || strcasecmp($status, 'Rejected') == 0): ?>
                                    <span class="badge bg-danger fs-6"><i class="fa-solid fa-circle-xmark me-1"></i> Order Failed</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark fs-6"><i class="fa-solid fa-clock me-1"></i> Pending</span>
                                <?php endif; ?>
                            </div>

                            <!-- ከአድሚን የተላከ መልእክት ማሳያ (ሁልጊዜ መልእክት ካለ ያሳያል) -->
                            <?php if (!empty($admin_message)): ?>
                                <div class="alert alert-info border-0 mb-3 shadow-sm">
                                    <h6 class="fw-bold mb-1 text-dark">
                                        <i class="fa-solid fa-comment-dots text-primary me-2"></i>ከአድሚን የተላከ መልእክት፦
                                    </h6>
                                    <p class="mb-0 text-dark small fs-6" style="white-space: pre-line;"><?php echo htmlspecialchars($admin_message); ?></p>
                                </div>
                            <?php else: ?>
                                <div class="text-muted small mb-3 fst-italic">
                                    <i class="fa-solid fa-info-circle me-1"></i> ከአድሚን የተላከ ተጨማሪ መልእክት የለም።
                                </div>
                            <?php endif; ?>

                            <!-- ክፍያው ከተረጋገጠ የሚታይ Pickup Code -->
                            <?php if (strcasecmp($status, 'Paid') == 0 || strcasecmp($status, 'Completed') == 0): ?>
                                <div class="card bg-warning text-dark text-center border-0 p-3 mb-3">
                                    <span class="small fw-bold">እቃ መቀበያ ኮድ (Pickup Code)</span>
                                    <h2 class="fw-bold my-1"><?php echo htmlspecialchars($order_details['pickup_code'] ?? 'N/A'); ?></h2>
                                </div>
                            <?php endif; ?>

                            <div class="small text-muted">
                                <div><strong>ስም፦</strong> <?php echo htmlspecialchars(($order_details['first_name'] ?? '') . ' ' . ($order_details['last_name'] ?? '')); ?></div>
                                <div><strong>Transaction ID፦</strong> <?php echo htmlspecialchars($order_details['tx_ref'] ?? 'N/A'); ?></div>
                                <div><strong>መጠን፦</strong> <?php echo number_format($order_details['amount'] ?? 0, 2); ?> ETB</div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning text-center">በዚህ መረጃ የተመዘገበ ትዕዛዝ አልተገኘም።</div>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
    </div>

</body>
</html>














