<?php
session_start();
include 'config/db.php';

// ደንበኛው Login ማድረጉን ማረጋገጥ (ከፈለግህ Session ማረጋገጫውን ማብራት ትችላለህ)
if (!isset($_SESSION['user_id'])) {
    // header("Location: login.php");
}

if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    die("ትክክለኛ የትዕዛዝ ቁጥር አልተገኘም።");
}

$order_id = intval($_GET['order_id']);

// ደንበኛው የራሱን ትዕዛዝ ብቻ እንዲያይ በ user_id መገደብ ይቻላል
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("የተፈለገው ትዕዛዝ አልተገኘም።");
}

$order = $result->fetch_assoc();
$stmt->close();

$raw_product_name = $order['product_name'] ?? 'N/A';
$city = $order['city'] ?? 'N/A';
$area = $order['area'] ?? 'N/A';

$clean_product_name = trim(preg_replace('/\[የማድረሻ ቦታ:.*?\]/su', '', $raw_product_name));
?>

<!DOCTYPE html>
<html lang="am">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>የእርስዎ ደረሰኝ - Order #<?php echo $order['id']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .invoice-card { max-width: 750px; margin: 30px auto; background: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .invoice-header { border-bottom: 2px dashed #de4436; padding-bottom: 20px; margin-bottom: 20px; }
        .pickup-notice { background-color: #fff8e1; border: 1px dashed #ffe082; border-radius: 8px; padding: 15px; margin-bottom: 25px; }
        @media print {
            body { background-color: #fff; }
            .no-print { display: none !important; }
            .invoice-card { box-shadow: none; border: none; padding: 0; margin: 0; max-width: 100%; }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Action Buttons -->
    <div class="text-center mt-4 no-print">
        <button onclick="window.print()" class="btn btn-success btn-lg px-4 me-2">
            <i class="fa-solid fa-print me-2"></i> ደረሰኙን አትም / Download PDF
        </button>
        <a href="index.php" class="btn btn-outline-secondary btn-lg px-4">
            <i class="fa-solid fa-house me-2"></i> ወደ ዋና ገፅ ተመለስ
        </a>
    </div>

    <div class="invoice-card">
        <!-- Header -->
        <div class="invoice-header d-flex justify-content-between align-items-center">
            <div>
                <h3 class="fw-bold text-danger m-0"><i class="fa-solid fa-bag-shopping me-2"></i> የሱቅህ ስም</h3>
                <small class="text-muted">የእዎ መገበያያ ማዕከል</small>
            </div>
            <div class="text-end">
                <h5 class="fw-bold text-uppercase m-0">የግዢ ደረሰኝ</h5>
                <span class="text-muted small">ቁጥር፦ #INV-<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></span>
            </div>
        </div>

        <!-- ደንበኛው እቃ ሲቀበል የሚያሳይ ማስታወሻ -->
        <div class="pickup-notice text-center">
            <h6 class="fw-bold text-warning-emphasis mb-1">
                <i class="fa-solid fa-triangle-exclamation me-1"></i> እቃውን ሲረከቡ ይህንን ደረሰኝ እና የPickup Code ይያዙ!
            </h6>
            <p class="small text-muted mb-0">እቃውን በሚረከቡበት ወቅት ይህንን ደረሰኝ በስልክዎ በማሳየት ወይም የወረቀት ህትመቱን በመስጠት መረከብ ይችላሉ።</p>
        </div>

        <!-- User & Order Info -->
        <div class="row mb-4">
            <div class="col-6">
                <h6 class="fw-bold text-secondary text-uppercase small mb-2">የደንበኛ መረጃ፦</h6>
                <h6 class="fw-bold mb-1"><?php echo htmlspecialchars(($order['first_name'] ?? '') . ' ' . ($order['last_name'] ?? '')); ?></h6>
                <p class="mb-1 text-muted small"><i class="fa-solid fa-phone me-1"></i> <?php echo htmlspecialchars($order['phone'] ?? ''); ?></p>
                <p class="mb-0 text-muted small"><i class="fa-solid fa-location-dot me-1"></i> <?php echo htmlspecialchars($city . ', ' . $area); ?></p>
            </div>
            <div class="col-6 text-end">
                <h6 class="fw-bold text-secondary text-uppercase small mb-2">የትዕዛዝ መረጃ፦</h6>
                <p class="mb-1 small"><strong>ቀን፦</strong> <?php echo isset($order['created_at']) ? date('M d, Y - h:i A', strtotime($order['created_at'])) : date('M d, Y'); ?></p>
                <p class="mb-1 small"><strong>Pickup Code፦</strong> <span class="badge bg-danger fs-6 font-monospace"><?php echo htmlspecialchars($order['pickup_code'] ?? 'N/A'); ?></span></p>
                <p class="mb-0 small"><strong>Txn Ref፦</strong> <code class="text-primary"><?php echo htmlspecialchars($order['tx_ref'] ?? 'N/A'); ?></code></p>
            </div>
        </div>

        <!-- Items Table -->
        <div class="table-responsive mb-3">
            <table class="table table-bordered align-middle">
                <thead class="table-light">
                    <tr>
                        <th>የተገዛው እቃ</th>
                        <th class="text-end">ዋጋ</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($clean_product_name); ?></strong></td>
                        <td class="text-end fw-bold"><?php echo number_format($order['amount'] ?? 0, 2); ?> ETB</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Total -->
        <div class="row justify-content-end mb-4">
            <div class="col-md-6">
                <table class="table table-borderless m-0">
                    <tr class="border-top">
                        <td class="text-start fs-5 fw-bold">ጠቅላላ የተከፈለ፦</td>
                        <td class="text-end fs-5 fw-bold text-success"><?php echo number_format($order['amount'] ?? 0, 2); ?> ETB</td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="border-top pt-3 text-center text-muted small">
            <p class="mb-0">ስለገዙን እናመሰግናለን! | የደንበኞች አገልግሎት፦ +251 926680499</p>
        </div>
    </div>
</div>

</body>
</html>